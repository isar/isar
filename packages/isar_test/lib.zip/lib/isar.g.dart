// ignore_for_file: unused_import, implementation_imports

import 'dart:ffi';
import 'dart:convert';
import 'dart:isolate';
import 'dart:typed_data';
import 'dart:io';
import 'package:isar/isar.dart';
import 'package:isar/src/isar_native.dart';
import 'package:isar/src/isar_interface.dart';
import 'package:isar/src/query_builder.dart';
import 'package:ffi/ffi.dart';
import 'package:path/path.dart' as p;
import 'models/bool_model.dart';
import 'models/long_model.dart';
import 'models/mutli_type_model.dart';
import 'models/int_model.dart';
import 'models/string_model.dart';
import 'models/float_model.dart';
import 'models/date_time_model.dart';
import 'models/user_model.dart';
import 'models/link_model.dart';
import 'models/converter_model.dart';
import 'models/message_model.dart';
import 'models/string_model_cis.dart';
import 'models/double_model.dart';
import 'package:isar_test/models/converter_model.dart';

final _isar = <String, Isar>{};
const _utf8Encoder = Utf8Encoder();

final _schema =
    '[{"name":"BoolModel","idProperty":"id","properties":[{"name":"id","type":3},{"name":"field","type":0}],"indexes":[{"unique":false,"replace":false,"properties":[{"name":"field","indexType":0,"caseSensitive":null}]}],"links":[]},{"name":"LongModel","idProperty":"id","properties":[{"name":"id","type":3},{"name":"field","type":3}],"indexes":[{"unique":false,"replace":false,"properties":[{"name":"field","indexType":0,"caseSensitive":null}]}],"links":[]},{"name":"MultiTypeModel","idProperty":"id","properties":[{"name":"id","type":3},{"name":"boolValue","type":0},{"name":"intValue","type":1},{"name":"floatValue","type":2},{"name":"longValue","type":3},{"name":"doubleValue","type":4},{"name":"dateTimeValue","type":3},{"name":"stringValue","type":5},{"name":"bytesValue","type":6},{"name":"boolList","type":6},{"name":"intList","type":7},{"name":"floatList","type":8},{"name":"longList","type":9},{"name":"doubleList","type":10},{"name":"dateTimeListValue","type":9},{"name":"stringList","type":11}],"indexes":[],"links":[]},{"name":"IntModel","idProperty":"id","properties":[{"name":"id","type":3},{"name":"field","type":1}],"indexes":[{"unique":false,"replace":false,"properties":[{"name":"field","indexType":0,"caseSensitive":null}]}],"links":[]},{"name":"StringModel","idProperty":"id","properties":[{"name":"id","type":3},{"name":"hashField","type":5},{"name":"valueField","type":5},{"name":"wordsField","type":5}],"indexes":[{"unique":false,"replace":false,"properties":[{"name":"hashField","indexType":1,"caseSensitive":true}]},{"unique":false,"replace":false,"properties":[{"name":"valueField","indexType":0,"caseSensitive":true}]},{"unique":false,"replace":false,"properties":[{"name":"wordsField","indexType":2,"caseSensitive":true}]}],"links":[]},{"name":"FloatModel","idProperty":"id","properties":[{"name":"id","type":3},{"name":"field","type":2}],"indexes":[{"unique":false,"replace":false,"properties":[{"name":"field","indexType":0,"caseSensitive":null}]}],"links":[]},{"name":"DateTimeModel","idProperty":"id","properties":[{"name":"id","type":3},{"name":"date","type":3},{"name":"dateNullable","type":3},{"name":"list","type":9},{"name":"listNullable","type":9},{"name":"listElementNullable","type":9},{"name":"listNullableElementNullable","type":9}],"indexes":[{"unique":false,"replace":false,"properties":[{"name":"date","indexType":0,"caseSensitive":null}]},{"unique":false,"replace":false,"properties":[{"name":"dateNullable","indexType":0,"caseSensitive":null}]}],"links":[]},{"name":"UserModel","idProperty":"id","properties":[{"name":"id","type":3},{"name":"name","type":5},{"name":"age","type":3},{"name":"admin","type":0}],"indexes":[{"unique":false,"replace":false,"properties":[{"name":"name","indexType":1,"caseSensitive":true}]},{"unique":false,"replace":false,"properties":[{"name":"age","indexType":0,"caseSensitive":null}]}],"links":[]},{"name":"LinkModelA","idProperty":"id","properties":[{"name":"id","type":3},{"name":"name","type":5}],"indexes":[],"links":[{"name":"selfLink","collection":"LinkModelA"},{"name":"otherLink","collection":"LinkModelB"},{"name":"selfLinks","collection":"LinkModelA"},{"name":"otherLinks","collection":"LinkModelB"}]},{"name":"LinkModelB","idProperty":"id","properties":[{"name":"id","type":3},{"name":"name","type":5}],"indexes":[],"links":[]},{"name":"ConverterModel","idProperty":"id","properties":[{"name":"id","type":3},{"name":"boolValue","type":5},{"name":"intValue","type":5},{"name":"longValue","type":5},{"name":"floatValue","type":5},{"name":"doubleValue","type":5},{"name":"dateValue","type":5},{"name":"stringValue","type":3}],"indexes":[{"unique":false,"replace":false,"properties":[{"name":"boolValue","indexType":1,"caseSensitive":true}]},{"unique":false,"replace":false,"properties":[{"name":"intValue","indexType":1,"caseSensitive":true}]},{"unique":false,"replace":false,"properties":[{"name":"longValue","indexType":1,"caseSensitive":true}]},{"unique":false,"replace":false,"properties":[{"name":"floatValue","indexType":1,"caseSensitive":true}]},{"unique":false,"replace":false,"properties":[{"name":"doubleValue","indexType":1,"caseSensitive":true}]},{"unique":false,"replace":false,"properties":[{"name":"dateValue","indexType":1,"caseSensitive":true}]},{"unique":false,"replace":false,"properties":[{"name":"stringValue","indexType":0,"caseSensitive":null}]}],"links":[]},{"name":"Message","idProperty":"id","properties":[{"name":"id","type":3},{"name":"message","type":5}],"indexes":[{"unique":false,"replace":false,"properties":[{"name":"message","indexType":1,"caseSensitive":true}]}],"links":[]},{"name":"StringModelCIS","idProperty":"id","properties":[{"name":"id","type":3},{"name":"hashField","type":5},{"name":"valueField","type":5},{"name":"wordsField","type":5}],"indexes":[{"unique":false,"replace":false,"properties":[{"name":"hashField","indexType":1,"caseSensitive":false}]},{"unique":false,"replace":false,"properties":[{"name":"valueField","indexType":0,"caseSensitive":false}]},{"unique":false,"replace":false,"properties":[{"name":"wordsField","indexType":2,"caseSensitive":false}]}],"links":[]},{"name":"DoubleModel","idProperty":"id","properties":[{"name":"id","type":3},{"name":"field","type":4}],"indexes":[{"unique":false,"replace":false,"properties":[{"name":"field","indexType":0,"caseSensitive":null}]}],"links":[]}]';

final _boolModelCollection = <String, IsarCollection<BoolModel>>{};
final _longModelCollection = <String, IsarCollection<LongModel>>{};
final _multiTypeModelCollection = <String, IsarCollection<MultiTypeModel>>{};
final _intModelCollection = <String, IsarCollection<IntModel>>{};
final _stringModelCollection = <String, IsarCollection<StringModel>>{};
final _floatModelCollection = <String, IsarCollection<FloatModel>>{};
final _dateTimeModelCollection = <String, IsarCollection<DateTimeModel>>{};
final _userModelCollection = <String, IsarCollection<UserModel>>{};
final _linkModelACollection = <String, IsarCollection<LinkModelA>>{};
final _linkModelBCollection = <String, IsarCollection<LinkModelB>>{};
final _converterModelCollection = <String, IsarCollection<ConverterModel>>{};
final _messageCollection = <String, IsarCollection<Message>>{};
final _stringModelCISCollection = <String, IsarCollection<StringModelCIS>>{};
final _doubleModelCollection = <String, IsarCollection<DoubleModel>>{};

Future<Isar> openIsar(
    {String name = 'isar',
    String? directory,
    int maxSize = 1000000000,
    Uint8List? encryptionKey}) async {
  assert(name.isNotEmpty);
  final path = await _preparePath(directory);
  if (_isar[name] != null) {
    return _isar[name]!;
  }
  await Directory(p.join(path, name)).create(recursive: true);
  initializeIsarCore();
  IC.isar_connect_dart_api(NativeApi.postCObject);

  final isarPtrPtr = malloc<Pointer>();
  final namePtr = name.toNativeUtf8();
  final pathPtr = path.toNativeUtf8();
  IC.isar_get_instance(isarPtrPtr, namePtr.cast());
  if (isarPtrPtr.value.address == 0) {
    final schemaPtr = _schema.toNativeUtf8();
    var encKeyPtr = Pointer<Uint8>.fromAddress(0);
    if (encryptionKey != null) {
      assert(encryptionKey.length == 32,
          'Encryption keys need to contain 32 byte (256bit).');
      encKeyPtr = malloc(32);
      encKeyPtr.asTypedList(32).setAll(0, encryptionKey);
    }
    final receivePort = ReceivePort();
    final nativePort = receivePort.sendPort.nativePort;
    final stream = wrapIsarPort(receivePort);
    IC.isar_create_instance(isarPtrPtr, namePtr.cast(), pathPtr.cast(), maxSize,
        schemaPtr.cast(), encKeyPtr, nativePort);
    await stream.first;
    malloc.free(schemaPtr);
    if (encryptionKey != null) {
      malloc.free(encKeyPtr);
    }
  }
  malloc.free(namePtr);
  malloc.free(pathPtr);

  final isarPtr = isarPtrPtr.value;
  malloc.free(isarPtrPtr);

  final isar = IsarImpl(name, isarPtr);
  _isar[name] = isar;

  final collectionPtrPtr = malloc<Pointer>();
  final propertyOffsetsPtr = malloc<Uint32>(16);
  final propertyOffsets = propertyOffsetsPtr.asTypedList(16);
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 0));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _boolModelCollection[name] = IsarCollectionImpl(
    isar,
    _BoolModelAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 2),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 1));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _longModelCollection[name] = IsarCollectionImpl(
    isar,
    _LongModelAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 2),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 2));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _multiTypeModelCollection[name] = IsarCollectionImpl(
    isar,
    _MultiTypeModelAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 16),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 3));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _intModelCollection[name] = IsarCollectionImpl(
    isar,
    _IntModelAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 2),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 4));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _stringModelCollection[name] = IsarCollectionImpl(
    isar,
    _StringModelAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 4),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 5));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _floatModelCollection[name] = IsarCollectionImpl(
    isar,
    _FloatModelAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 2),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 6));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _dateTimeModelCollection[name] = IsarCollectionImpl(
    isar,
    _DateTimeModelAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 7),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 7));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _userModelCollection[name] = IsarCollectionImpl(
    isar,
    _UserModelAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 4),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 8));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _linkModelACollection[name] = IsarCollectionImpl(
    isar,
    _LinkModelAAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 2),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 9));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _linkModelBCollection[name] = IsarCollectionImpl(
    isar,
    _LinkModelBAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 2),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 10));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _converterModelCollection[name] = IsarCollectionImpl(
    isar,
    _ConverterModelAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 8),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 11));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _messageCollection[name] = IsarCollectionImpl(
    isar,
    _MessageAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 2),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 12));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _stringModelCISCollection[name] = IsarCollectionImpl(
    isar,
    _StringModelCISAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 4),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  nCall(IC.isar_get_collection(isarPtr, collectionPtrPtr, 13));
  IC.isar_get_property_offsets(collectionPtrPtr.value, propertyOffsetsPtr);
  _doubleModelCollection[name] = IsarCollectionImpl(
    isar,
    _DoubleModelAdapter(),
    collectionPtrPtr.value,
    propertyOffsets.sublist(0, 2),
    (obj) => obj.id,
    (obj, id) => obj.id = id,
  );
  malloc.free(propertyOffsetsPtr);
  malloc.free(collectionPtrPtr);

  IsarInterface.initialize(_GeneratedIsarInterface());
  Isar.addCloseListener(_onClose);

  return isar;
}

void _onClose(String name) {
  _isar.remove(name);
}

Future<String> _preparePath(String? path) async {
  if (path == null || p.isRelative(path)) {
    return p.absolute(path ?? '');
  } else {
    return path;
  }
}

extension GetCollection on Isar {
  IsarCollection<BoolModel> get boolModels {
    return _boolModelCollection[name]!;
  }

  IsarCollection<LongModel> get longModels {
    return _longModelCollection[name]!;
  }

  IsarCollection<MultiTypeModel> get multiTypeModels {
    return _multiTypeModelCollection[name]!;
  }

  IsarCollection<IntModel> get intModels {
    return _intModelCollection[name]!;
  }

  IsarCollection<StringModel> get stringModels {
    return _stringModelCollection[name]!;
  }

  IsarCollection<FloatModel> get floatModels {
    return _floatModelCollection[name]!;
  }

  IsarCollection<DateTimeModel> get dateTimeModels {
    return _dateTimeModelCollection[name]!;
  }

  IsarCollection<UserModel> get userModels {
    return _userModelCollection[name]!;
  }

  IsarCollection<LinkModelA> get linkModelAs {
    return _linkModelACollection[name]!;
  }

  IsarCollection<LinkModelB> get linkModelBs {
    return _linkModelBCollection[name]!;
  }

  IsarCollection<ConverterModel> get converterModels {
    return _converterModelCollection[name]!;
  }

  IsarCollection<Message> get messages {
    return _messageCollection[name]!;
  }

  IsarCollection<StringModelCIS> get stringModelCISs {
    return _stringModelCISCollection[name]!;
  }

  IsarCollection<DoubleModel> get doubleModels {
    return _doubleModelCollection[name]!;
  }
}

class _BoolModelAdapter extends TypeAdapter<BoolModel> {
  @override
  int serialize(IsarCollectionImpl<BoolModel> collection, RawObject rawObj,
      BoolModel object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.field;
    final _field = value1;
    final size = dynamicSize + 11;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 11);
    writer.writeLong(offsets[0], _id);
    writer.writeBool(offsets[1], _field);
    return bufferSize;
  }

  @override
  BoolModel deserialize(IsarCollectionImpl<BoolModel> collection,
      BinaryReader reader, List<int> offsets) {
    final object = BoolModel();
    object.id = reader.readLongOrNull(offsets[0]);
    object.field = reader.readBoolOrNull(offsets[1]);
    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readBoolOrNull(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _LongModelAdapter extends TypeAdapter<LongModel> {
  @override
  int serialize(IsarCollectionImpl<LongModel> collection, RawObject rawObj,
      LongModel object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.field;
    final _field = value1;
    final size = dynamicSize + 18;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 18);
    writer.writeLong(offsets[0], _id);
    writer.writeLong(offsets[1], _field);
    return bufferSize;
  }

  @override
  LongModel deserialize(IsarCollectionImpl<LongModel> collection,
      BinaryReader reader, List<int> offsets) {
    final object = LongModel();
    object.id = reader.readLongOrNull(offsets[0]);
    object.field = reader.readLongOrNull(offsets[1]);
    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readLongOrNull(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _MultiTypeModelAdapter extends TypeAdapter<MultiTypeModel> {
  @override
  int serialize(IsarCollectionImpl<MultiTypeModel> collection, RawObject rawObj,
      MultiTypeModel object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.boolValue;
    final _boolValue = value1;
    final value2 = object.intValue;
    final _intValue = value2;
    final value3 = object.floatValue;
    final _floatValue = value3;
    final value4 = object.longValue;
    final _longValue = value4;
    final value5 = object.doubleValue;
    final _doubleValue = value5;
    final value6 = object.dateTimeValue;
    final _dateTimeValue = value6;
    final value7 = object.stringValue;
    Uint8List? _stringValue;
    if (value7 != null) {
      _stringValue = _utf8Encoder.convert(value7);
    }
    dynamicSize += _stringValue?.length ?? 0;
    final value8 = object.bytesValue;
    dynamicSize += (value8?.length ?? 0) * 1;
    final _bytesValue = value8;
    final value9 = object.boolList;
    dynamicSize += (value9?.length ?? 0) * 1;
    final _boolList = value9;
    final value10 = object.intList;
    dynamicSize += (value10?.length ?? 0) * 4;
    final _intList = value10;
    final value11 = object.floatList;
    dynamicSize += (value11?.length ?? 0) * 4;
    final _floatList = value11;
    final value12 = object.longList;
    dynamicSize += (value12?.length ?? 0) * 8;
    final _longList = value12;
    final value13 = object.doubleList;
    dynamicSize += (value13?.length ?? 0) * 8;
    final _doubleList = value13;
    final value14 = object.dateTimeListValue;
    dynamicSize += (value14?.length ?? 0) * 8;
    final _dateTimeListValue = value14;
    final value15 = object.stringList;
    dynamicSize += (value15?.length ?? 0) * 8;
    List<Uint8List?>? bytesList15;
    if (value15 != null) {
      bytesList15 = [];
      for (var str in value15) {
        final bytes = _utf8Encoder.convert(str);
        bytesList15.add(bytes);
        dynamicSize += bytes.length;
      }
    }
    final _stringList = bytesList15;
    final size = dynamicSize + 115;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 115);
    writer.writeLong(offsets[0], _id);
    writer.writeBool(offsets[1], _boolValue);
    writer.writeInt(offsets[2], _intValue);
    writer.writeFloat(offsets[3], _floatValue);
    writer.writeLong(offsets[4], _longValue);
    writer.writeDouble(offsets[5], _doubleValue);
    writer.writeDateTime(offsets[6], _dateTimeValue);
    writer.writeBytes(offsets[7], _stringValue);
    writer.writeBytes(offsets[8], _bytesValue);
    writer.writeBoolList(offsets[9], _boolList);
    writer.writeIntList(offsets[10], _intList);
    writer.writeFloatList(offsets[11], _floatList);
    writer.writeLongList(offsets[12], _longList);
    writer.writeDoubleList(offsets[13], _doubleList);
    writer.writeDateTimeList(offsets[14], _dateTimeListValue);
    writer.writeStringList(offsets[15], _stringList);
    return bufferSize;
  }

  @override
  MultiTypeModel deserialize(IsarCollectionImpl<MultiTypeModel> collection,
      BinaryReader reader, List<int> offsets) {
    final object = MultiTypeModel();
    object.id = reader.readLongOrNull(offsets[0]);
    object.boolValue = reader.readBoolOrNull(offsets[1]);
    object.intValue = reader.readIntOrNull(offsets[2]);
    object.floatValue = reader.readFloatOrNull(offsets[3]);
    object.longValue = reader.readLongOrNull(offsets[4]);
    object.doubleValue = reader.readDoubleOrNull(offsets[5]);
    object.dateTimeValue = reader.readDateTimeOrNull(offsets[6]);
    object.stringValue = reader.readStringOrNull(offsets[7]);
    object.bytesValue = reader.readBytesOrNull(offsets[8]);
    object.boolList = reader.readBoolList(offsets[9]);
    object.intList = reader.readIntList(offsets[10]);
    object.floatList = reader.readFloatList(offsets[11]);
    object.longList = reader.readLongList(offsets[12]);
    object.doubleList = reader.readDoubleList(offsets[13]);
    object.dateTimeListValue = reader.readDateTimeList(offsets[14]);
    object.stringList = reader.readStringList(offsets[15]);
    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readBoolOrNull(offset)) as P;
      case 2:
        return (reader.readIntOrNull(offset)) as P;
      case 3:
        return (reader.readFloatOrNull(offset)) as P;
      case 4:
        return (reader.readLongOrNull(offset)) as P;
      case 5:
        return (reader.readDoubleOrNull(offset)) as P;
      case 6:
        return (reader.readDateTimeOrNull(offset)) as P;
      case 7:
        return (reader.readStringOrNull(offset)) as P;
      case 8:
        return (reader.readBytesOrNull(offset)) as P;
      case 9:
        return (reader.readBoolList(offset)) as P;
      case 10:
        return (reader.readIntList(offset)) as P;
      case 11:
        return (reader.readFloatList(offset)) as P;
      case 12:
        return (reader.readLongList(offset)) as P;
      case 13:
        return (reader.readDoubleList(offset)) as P;
      case 14:
        return (reader.readDateTimeList(offset)) as P;
      case 15:
        return (reader.readStringList(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _IntModelAdapter extends TypeAdapter<IntModel> {
  @override
  int serialize(IsarCollectionImpl<IntModel> collection, RawObject rawObj,
      IntModel object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.field;
    final _field = value1;
    final size = dynamicSize + 14;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 14);
    writer.writeLong(offsets[0], _id);
    writer.writeInt(offsets[1], _field);
    return bufferSize;
  }

  @override
  IntModel deserialize(IsarCollectionImpl<IntModel> collection,
      BinaryReader reader, List<int> offsets) {
    final object = IntModel();
    object.id = reader.readLongOrNull(offsets[0]);
    object.field = reader.readIntOrNull(offsets[1]);
    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readIntOrNull(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _StringModelAdapter extends TypeAdapter<StringModel> {
  @override
  int serialize(IsarCollectionImpl<StringModel> collection, RawObject rawObj,
      StringModel object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.hashField;
    Uint8List? _hashField;
    if (value1 != null) {
      _hashField = _utf8Encoder.convert(value1);
    }
    dynamicSize += _hashField?.length ?? 0;
    final value2 = object.valueField;
    Uint8List? _valueField;
    if (value2 != null) {
      _valueField = _utf8Encoder.convert(value2);
    }
    dynamicSize += _valueField?.length ?? 0;
    final value3 = object.wordsField;
    Uint8List? _wordsField;
    if (value3 != null) {
      _wordsField = _utf8Encoder.convert(value3);
    }
    dynamicSize += _wordsField?.length ?? 0;
    final size = dynamicSize + 34;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 34);
    writer.writeLong(offsets[0], _id);
    writer.writeBytes(offsets[1], _hashField);
    writer.writeBytes(offsets[2], _valueField);
    writer.writeBytes(offsets[3], _wordsField);
    return bufferSize;
  }

  @override
  StringModel deserialize(IsarCollectionImpl<StringModel> collection,
      BinaryReader reader, List<int> offsets) {
    final object = StringModel();
    object.id = reader.readLongOrNull(offsets[0]);
    object.hashField = reader.readStringOrNull(offsets[1]);
    object.valueField = reader.readStringOrNull(offsets[2]);
    object.wordsField = reader.readStringOrNull(offsets[3]);
    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readStringOrNull(offset)) as P;
      case 2:
        return (reader.readStringOrNull(offset)) as P;
      case 3:
        return (reader.readStringOrNull(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _FloatModelAdapter extends TypeAdapter<FloatModel> {
  @override
  int serialize(IsarCollectionImpl<FloatModel> collection, RawObject rawObj,
      FloatModel object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.field;
    final _field = value1;
    final size = dynamicSize + 14;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 14);
    writer.writeLong(offsets[0], _id);
    writer.writeFloat(offsets[1], _field);
    return bufferSize;
  }

  @override
  FloatModel deserialize(IsarCollectionImpl<FloatModel> collection,
      BinaryReader reader, List<int> offsets) {
    final object = FloatModel();
    object.id = reader.readLongOrNull(offsets[0]);
    object.field = reader.readFloatOrNull(offsets[1]);
    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readFloatOrNull(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _DateTimeModelAdapter extends TypeAdapter<DateTimeModel> {
  @override
  int serialize(IsarCollectionImpl<DateTimeModel> collection, RawObject rawObj,
      DateTimeModel object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.date;
    final _date = value1;
    final value2 = object.dateNullable;
    final _dateNullable = value2;
    final value3 = object.list;
    dynamicSize += (value3.length) * 8;
    final _list = value3;
    final value4 = object.listNullable;
    dynamicSize += (value4?.length ?? 0) * 8;
    final _listNullable = value4;
    final value5 = object.listElementNullable;
    dynamicSize += (value5.length) * 8;
    final _listElementNullable = value5;
    final value6 = object.listNullableElementNullable;
    dynamicSize += (value6?.length ?? 0) * 8;
    final _listNullableElementNullable = value6;
    final size = dynamicSize + 58;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 58);
    writer.writeLong(offsets[0], _id);
    writer.writeDateTime(offsets[1], _date);
    writer.writeDateTime(offsets[2], _dateNullable);
    writer.writeDateTimeList(offsets[3], _list);
    writer.writeDateTimeList(offsets[4], _listNullable);
    writer.writeDateTimeList(offsets[5], _listElementNullable);
    writer.writeDateTimeList(offsets[6], _listNullableElementNullable);
    return bufferSize;
  }

  @override
  DateTimeModel deserialize(IsarCollectionImpl<DateTimeModel> collection,
      BinaryReader reader, List<int> offsets) {
    final object = DateTimeModel();
    object.id = reader.readLongOrNull(offsets[0]);
    object.date = reader.readDateTime(offsets[1]);
    object.dateNullable = reader.readDateTimeOrNull(offsets[2]);
    object.list = reader.readDateTimeList(offsets[3]) ?? [];
    object.listNullable = reader.readDateTimeList(offsets[4]);
    object.listElementNullable =
        reader.readDateTimeOrNullList(offsets[5]) ?? [];
    object.listNullableElementNullable =
        reader.readDateTimeOrNullList(offsets[6]);
    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readDateTime(offset)) as P;
      case 2:
        return (reader.readDateTimeOrNull(offset)) as P;
      case 3:
        return (reader.readDateTimeList(offset) ?? []) as P;
      case 4:
        return (reader.readDateTimeList(offset)) as P;
      case 5:
        return (reader.readDateTimeOrNullList(offset) ?? []) as P;
      case 6:
        return (reader.readDateTimeOrNullList(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _UserModelAdapter extends TypeAdapter<UserModel> {
  @override
  int serialize(IsarCollectionImpl<UserModel> collection, RawObject rawObj,
      UserModel object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.name;
    Uint8List? _name;
    if (value1 != null) {
      _name = _utf8Encoder.convert(value1);
    }
    dynamicSize += _name?.length ?? 0;
    final value2 = object.age;
    final _age = value2;
    final value3 = object.admin;
    final _admin = value3;
    final size = dynamicSize + 27;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 27);
    writer.writeLong(offsets[0], _id);
    writer.writeBytes(offsets[1], _name);
    writer.writeLong(offsets[2], _age);
    writer.writeBool(offsets[3], _admin);
    return bufferSize;
  }

  @override
  UserModel deserialize(IsarCollectionImpl<UserModel> collection,
      BinaryReader reader, List<int> offsets) {
    final object = UserModel();
    object.id = reader.readLongOrNull(offsets[0]);
    object.name = reader.readStringOrNull(offsets[1]);
    object.age = reader.readLongOrNull(offsets[2]);
    object.admin = reader.readBool(offsets[3]);
    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readStringOrNull(offset)) as P;
      case 2:
        return (reader.readLongOrNull(offset)) as P;
      case 3:
        return (reader.readBool(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _LinkModelAAdapter extends TypeAdapter<LinkModelA> {
  @override
  int serialize(IsarCollectionImpl<LinkModelA> collection, RawObject rawObj,
      LinkModelA object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.name;
    final _name = _utf8Encoder.convert(value1);
    dynamicSize += _name.length;
    final size = dynamicSize + 18;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 18);
    writer.writeLong(offsets[0], _id);
    writer.writeBytes(offsets[1], _name);
    if (!(object.selfLink as IsarLinkImpl).attached) {
      (object.selfLink as IsarLinkImpl).attach(
        collection,
        collection,
        object,
        0,
        false,
      );
    }
    if (!(object.otherLink as IsarLinkImpl).attached) {
      (object.otherLink as IsarLinkImpl).attach(
        collection,
        collection.isar.linkModelBs as IsarCollectionImpl<LinkModelB>,
        object,
        1,
        false,
      );
    }
    if (!(object.selfLinks as IsarLinksImpl).attached) {
      (object.selfLinks as IsarLinksImpl).attach(
        collection,
        collection,
        object,
        2,
        false,
      );
    }
    if (!(object.otherLinks as IsarLinksImpl).attached) {
      (object.otherLinks as IsarLinksImpl).attach(
        collection,
        collection.isar.linkModelBs as IsarCollectionImpl<LinkModelB>,
        object,
        3,
        false,
      );
    }
    if (!(object.selfLinkBacklink as IsarLinksImpl).attached) {
      (object.selfLinkBacklink as IsarLinksImpl).attach(
        collection,
        collection,
        object,
        0,
        true,
      );
    }
    if (!(object.selfLinksBacklink as IsarLinksImpl).attached) {
      (object.selfLinksBacklink as IsarLinksImpl).attach(
        collection,
        collection,
        object,
        2,
        true,
      );
    }
    return bufferSize;
  }

  @override
  LinkModelA deserialize(IsarCollectionImpl<LinkModelA> collection,
      BinaryReader reader, List<int> offsets) {
    final object = LinkModelA();
    object.id = reader.readLongOrNull(offsets[0]);
    object.name = reader.readString(offsets[1]);
    object.selfLink = IsarLinkImpl()
      ..attach(
        collection,
        collection,
        object,
        0,
        false,
      );
    object.otherLink = IsarLinkImpl()
      ..attach(
        collection,
        collection.isar.linkModelBs as IsarCollectionImpl<LinkModelB>,
        object,
        1,
        false,
      );
    object.selfLinks = IsarLinksImpl()
      ..attach(
        collection,
        collection,
        object,
        2,
        false,
      );
    object.otherLinks = IsarLinksImpl()
      ..attach(
        collection,
        collection.isar.linkModelBs as IsarCollectionImpl<LinkModelB>,
        object,
        3,
        false,
      );
    object.selfLinkBacklink = IsarLinksImpl()
      ..attach(
        collection,
        collection,
        object,
        0,
        true,
      );
    object.selfLinksBacklink = IsarLinksImpl()
      ..attach(
        collection,
        collection,
        object,
        2,
        true,
      );

    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readString(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _LinkModelBAdapter extends TypeAdapter<LinkModelB> {
  @override
  int serialize(IsarCollectionImpl<LinkModelB> collection, RawObject rawObj,
      LinkModelB object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.name;
    final _name = _utf8Encoder.convert(value1);
    dynamicSize += _name.length;
    final size = dynamicSize + 18;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 18);
    writer.writeLong(offsets[0], _id);
    writer.writeBytes(offsets[1], _name);
    if (!(object.linkBacklinks as IsarLinksImpl).attached) {
      (object.linkBacklinks as IsarLinksImpl).attach(
        collection,
        collection.isar.linkModelAs as IsarCollectionImpl<LinkModelA>,
        object,
        1,
        true,
      );
    }
    if (!(object.linksBacklinks as IsarLinksImpl).attached) {
      (object.linksBacklinks as IsarLinksImpl).attach(
        collection,
        collection.isar.linkModelAs as IsarCollectionImpl<LinkModelA>,
        object,
        3,
        true,
      );
    }
    return bufferSize;
  }

  @override
  LinkModelB deserialize(IsarCollectionImpl<LinkModelB> collection,
      BinaryReader reader, List<int> offsets) {
    final object = LinkModelB();
    object.id = reader.readLongOrNull(offsets[0]);
    object.name = reader.readString(offsets[1]);
    object.linkBacklinks = IsarLinksImpl()
      ..attach(
        collection,
        collection.isar.linkModelAs as IsarCollectionImpl<LinkModelA>,
        object,
        1,
        true,
      );
    object.linksBacklinks = IsarLinksImpl()
      ..attach(
        collection,
        collection.isar.linkModelAs as IsarCollectionImpl<LinkModelA>,
        object,
        3,
        true,
      );

    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readString(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _ConverterModelAdapter extends TypeAdapter<ConverterModel> {
  static const _BoolConverter = BoolConverter();
  static const _IntConverter = IntConverter();
  static const _DoubleConverter = DoubleConverter();
  static const _DateConverter = DateConverter();
  static const _StringConverter = StringConverter();

  @override
  int serialize(IsarCollectionImpl<ConverterModel> collection, RawObject rawObj,
      ConverterModel object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 =
        _ConverterModelAdapter._BoolConverter.toIsar(object.boolValue);
    final _boolValue = _utf8Encoder.convert(value1);
    dynamicSize += _boolValue.length;
    final value2 = _ConverterModelAdapter._IntConverter.toIsar(object.intValue);
    final _intValue = _utf8Encoder.convert(value2);
    dynamicSize += _intValue.length;
    final value3 =
        _ConverterModelAdapter._IntConverter.toIsar(object.longValue);
    final _longValue = _utf8Encoder.convert(value3);
    dynamicSize += _longValue.length;
    final value4 =
        _ConverterModelAdapter._DoubleConverter.toIsar(object.floatValue);
    final _floatValue = _utf8Encoder.convert(value4);
    dynamicSize += _floatValue.length;
    final value5 =
        _ConverterModelAdapter._DoubleConverter.toIsar(object.doubleValue);
    final _doubleValue = _utf8Encoder.convert(value5);
    dynamicSize += _doubleValue.length;
    final value6 =
        _ConverterModelAdapter._DateConverter.toIsar(object.dateValue);
    final _dateValue = _utf8Encoder.convert(value6);
    dynamicSize += _dateValue.length;
    final value7 =
        _ConverterModelAdapter._StringConverter.toIsar(object.stringValue);
    final _stringValue = value7;
    final size = dynamicSize + 66;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 66);
    writer.writeLong(offsets[0], _id);
    writer.writeBytes(offsets[1], _boolValue);
    writer.writeBytes(offsets[2], _intValue);
    writer.writeBytes(offsets[3], _longValue);
    writer.writeBytes(offsets[4], _floatValue);
    writer.writeBytes(offsets[5], _doubleValue);
    writer.writeBytes(offsets[6], _dateValue);
    writer.writeLong(offsets[7], _stringValue);
    return bufferSize;
  }

  @override
  ConverterModel deserialize(IsarCollectionImpl<ConverterModel> collection,
      BinaryReader reader, List<int> offsets) {
    final object = ConverterModel();
    object.id = reader.readLongOrNull(offsets[0]);
    object.boolValue = _ConverterModelAdapter._BoolConverter.fromIsar(
        reader.readString(offsets[1]));
    object.intValue = _ConverterModelAdapter._IntConverter.fromIsar(
        reader.readString(offsets[2]));
    object.longValue = _ConverterModelAdapter._IntConverter.fromIsar(
        reader.readString(offsets[3]));
    object.floatValue = _ConverterModelAdapter._DoubleConverter.fromIsar(
        reader.readString(offsets[4]));
    object.doubleValue = _ConverterModelAdapter._DoubleConverter.fromIsar(
        reader.readString(offsets[5]));
    object.dateValue = _ConverterModelAdapter._DateConverter.fromIsar(
        reader.readString(offsets[6]));
    object.stringValue = _ConverterModelAdapter._StringConverter.fromIsar(
        reader.readLong(offsets[7]));
    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (_ConverterModelAdapter._BoolConverter.fromIsar(
            reader.readString(offset))) as P;
      case 2:
        return (_ConverterModelAdapter._IntConverter.fromIsar(
            reader.readString(offset))) as P;
      case 3:
        return (_ConverterModelAdapter._IntConverter.fromIsar(
            reader.readString(offset))) as P;
      case 4:
        return (_ConverterModelAdapter._DoubleConverter.fromIsar(
            reader.readString(offset))) as P;
      case 5:
        return (_ConverterModelAdapter._DoubleConverter.fromIsar(
            reader.readString(offset))) as P;
      case 6:
        return (_ConverterModelAdapter._DateConverter.fromIsar(
            reader.readString(offset))) as P;
      case 7:
        return (_ConverterModelAdapter._StringConverter.fromIsar(
            reader.readLong(offset))) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _MessageAdapter extends TypeAdapter<Message> {
  @override
  int serialize(IsarCollectionImpl<Message> collection, RawObject rawObj,
      Message object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.message;
    Uint8List? _message;
    if (value1 != null) {
      _message = _utf8Encoder.convert(value1);
    }
    dynamicSize += _message?.length ?? 0;
    final size = dynamicSize + 18;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 18);
    writer.writeLong(offsets[0], _id);
    writer.writeBytes(offsets[1], _message);
    return bufferSize;
  }

  @override
  Message deserialize(IsarCollectionImpl<Message> collection,
      BinaryReader reader, List<int> offsets) {
    final object = Message();
    object.id = reader.readLongOrNull(offsets[0]);
    object.message = reader.readStringOrNull(offsets[1]);
    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readStringOrNull(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _StringModelCISAdapter extends TypeAdapter<StringModelCIS> {
  @override
  int serialize(IsarCollectionImpl<StringModelCIS> collection, RawObject rawObj,
      StringModelCIS object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.hashField;
    Uint8List? _hashField;
    if (value1 != null) {
      _hashField = _utf8Encoder.convert(value1);
    }
    dynamicSize += _hashField?.length ?? 0;
    final value2 = object.valueField;
    Uint8List? _valueField;
    if (value2 != null) {
      _valueField = _utf8Encoder.convert(value2);
    }
    dynamicSize += _valueField?.length ?? 0;
    final value3 = object.wordsField;
    Uint8List? _wordsField;
    if (value3 != null) {
      _wordsField = _utf8Encoder.convert(value3);
    }
    dynamicSize += _wordsField?.length ?? 0;
    final size = dynamicSize + 34;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 34);
    writer.writeLong(offsets[0], _id);
    writer.writeBytes(offsets[1], _hashField);
    writer.writeBytes(offsets[2], _valueField);
    writer.writeBytes(offsets[3], _wordsField);
    return bufferSize;
  }

  @override
  StringModelCIS deserialize(IsarCollectionImpl<StringModelCIS> collection,
      BinaryReader reader, List<int> offsets) {
    final object = StringModelCIS();
    object.id = reader.readLongOrNull(offsets[0]);
    object.hashField = reader.readStringOrNull(offsets[1]);
    object.valueField = reader.readStringOrNull(offsets[2]);
    object.wordsField = reader.readStringOrNull(offsets[3]);
    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readStringOrNull(offset)) as P;
      case 2:
        return (reader.readStringOrNull(offset)) as P;
      case 3:
        return (reader.readStringOrNull(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

class _DoubleModelAdapter extends TypeAdapter<DoubleModel> {
  @override
  int serialize(IsarCollectionImpl<DoubleModel> collection, RawObject rawObj,
      DoubleModel object, List<int> offsets,
      [int? existingBufferSize]) {
    var dynamicSize = 0;
    final value0 = object.id;
    final _id = value0;
    final value1 = object.field;
    final _field = value1;
    final size = dynamicSize + 18;

    late int bufferSize;
    if (existingBufferSize != null) {
      if (existingBufferSize < size) {
        malloc.free(rawObj.buffer);
        rawObj.buffer = malloc(size);
        bufferSize = size;
      } else {
        bufferSize = existingBufferSize;
      }
    } else {
      rawObj.buffer = malloc(size);
      bufferSize = size;
    }
    rawObj.buffer_length = size;
    final buffer = rawObj.buffer.asTypedList(size);
    final writer = BinaryWriter(buffer, 18);
    writer.writeLong(offsets[0], _id);
    writer.writeDouble(offsets[1], _field);
    return bufferSize;
  }

  @override
  DoubleModel deserialize(IsarCollectionImpl<DoubleModel> collection,
      BinaryReader reader, List<int> offsets) {
    final object = DoubleModel();
    object.id = reader.readLongOrNull(offsets[0]);
    object.field = reader.readDoubleOrNull(offsets[1]);
    return object;
  }

  @override
  P deserializeProperty<P>(BinaryReader reader, int propertyIndex, int offset) {
    switch (propertyIndex) {
      case 0:
        return (reader.readLongOrNull(offset)) as P;
      case 1:
        return (reader.readDoubleOrNull(offset)) as P;
      default:
        throw 'Illegal propertyIndex';
    }
  }
}

extension BoolModelQueryWhereSort on QueryBuilder<BoolModel, QWhere> {
  QueryBuilder<BoolModel, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }

  QueryBuilder<BoolModel, QAfterWhere> anyField() {
    return addWhereClause(WhereClause(0, []));
  }
}

extension BoolModelQueryWhere on QueryBuilder<BoolModel, QWhereClause> {
  QueryBuilder<BoolModel, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<BoolModel, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<BoolModel, QAfterWhereClause> idBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<BoolModel, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<BoolModel, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<BoolModel, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<BoolModel, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<BoolModel, QAfterWhereClause> fieldEqualTo(bool? field) {
    return addWhereClause(WhereClause(
      0,
      ['Bool'],
      upper: [field],
      includeUpper: true,
      lower: [field],
      includeLower: true,
    ));
  }

  QueryBuilder<BoolModel, QAfterWhereClause> fieldNotEqualTo(bool? field) {
    final cloned = addWhereClause(WhereClause(
      0,
      ['Bool'],
      upper: [field],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      0,
      ['Bool'],
      lower: [field],
      includeLower: false,
    ));
  }

  QueryBuilder<BoolModel, QAfterWhereClause> fieldIsNull() {
    return addWhereClause(WhereClause(
      0,
      ['Bool'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<BoolModel, QAfterWhereClause> fieldIsNotNull() {
    return addWhereClause(WhereClause(
      0,
      ['Bool'],
      lower: [null],
      includeLower: false,
    ));
  }
}

extension LongModelQueryWhereSort on QueryBuilder<LongModel, QWhere> {
  QueryBuilder<LongModel, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }

  QueryBuilder<LongModel, QAfterWhere> anyField() {
    return addWhereClause(WhereClause(0, []));
  }
}

extension LongModelQueryWhere on QueryBuilder<LongModel, QWhereClause> {
  QueryBuilder<LongModel, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> idBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> fieldEqualTo(int? field) {
    return addWhereClause(WhereClause(
      0,
      ['Long'],
      upper: [field],
      includeUpper: true,
      lower: [field],
      includeLower: true,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> fieldNotEqualTo(int? field) {
    final cloned = addWhereClause(WhereClause(
      0,
      ['Long'],
      upper: [field],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      0,
      ['Long'],
      lower: [field],
      includeLower: false,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> fieldBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      0,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> fieldGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      0,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> fieldLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      0,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> fieldIsNull() {
    return addWhereClause(WhereClause(
      0,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<LongModel, QAfterWhereClause> fieldIsNotNull() {
    return addWhereClause(WhereClause(
      0,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }
}

extension MultiTypeModelQueryWhereSort on QueryBuilder<MultiTypeModel, QWhere> {
  QueryBuilder<MultiTypeModel, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }
}

extension MultiTypeModelQueryWhere
    on QueryBuilder<MultiTypeModel, QWhereClause> {
  QueryBuilder<MultiTypeModel, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterWhereClause> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }
}

extension IntModelQueryWhereSort on QueryBuilder<IntModel, QWhere> {
  QueryBuilder<IntModel, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }

  QueryBuilder<IntModel, QAfterWhere> anyField() {
    return addWhereClause(WhereClause(0, []));
  }
}

extension IntModelQueryWhere on QueryBuilder<IntModel, QWhereClause> {
  QueryBuilder<IntModel, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> idBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> fieldEqualTo(int? field) {
    return addWhereClause(WhereClause(
      0,
      ['Int'],
      upper: [field],
      includeUpper: true,
      lower: [field],
      includeLower: true,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> fieldNotEqualTo(int? field) {
    final cloned = addWhereClause(WhereClause(
      0,
      ['Int'],
      upper: [field],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      0,
      ['Int'],
      lower: [field],
      includeLower: false,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> fieldBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      0,
      ['Int'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> fieldGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      0,
      ['Int'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> fieldLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      0,
      ['Int'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> fieldIsNull() {
    return addWhereClause(WhereClause(
      0,
      ['Int'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<IntModel, QAfterWhereClause> fieldIsNotNull() {
    return addWhereClause(WhereClause(
      0,
      ['Int'],
      lower: [null],
      includeLower: false,
    ));
  }
}

extension StringModelQueryWhereSort on QueryBuilder<StringModel, QWhere> {
  QueryBuilder<StringModel, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }

  QueryBuilder<StringModel, QAfterWhere> anyValueField() {
    return addWhereClause(WhereClause(1, []));
  }
}

extension StringModelQueryWhere on QueryBuilder<StringModel, QWhereClause> {
  QueryBuilder<StringModel, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> idBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> hashFieldEqualTo(
      String? hashField) {
    return addWhereClause(WhereClause(
      0,
      ['StringHash'],
      upper: [hashField],
      includeUpper: true,
      lower: [hashField],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> hashFieldNotEqualTo(
      String? hashField) {
    final cloned = addWhereClause(WhereClause(
      0,
      ['StringHash'],
      upper: [hashField],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      0,
      ['StringHash'],
      lower: [hashField],
      includeLower: false,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> hashFieldIsNull() {
    return addWhereClause(WhereClause(
      0,
      ['StringHash'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> hashFieldIsNotNull() {
    return addWhereClause(WhereClause(
      0,
      ['StringHash'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> valueFieldEqualTo(
      String? valueField) {
    return addWhereClause(WhereClause(
      1,
      ['StringValue'],
      upper: [valueField],
      includeUpper: true,
      lower: [valueField],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> valueFieldNotEqualTo(
      String? valueField) {
    final cloned = addWhereClause(WhereClause(
      1,
      ['StringValue'],
      upper: [valueField],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      1,
      ['StringValue'],
      lower: [valueField],
      includeLower: false,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> valueFieldStartsWith(
      String? value) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addWhereClause(WhereClause(
      1,
      ['StringValue'],
      lower: [convertedValue],
      upper: ['$convertedValue\u{FFFFF}'],
      includeLower: true,
      includeUpper: true,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> valueFieldIsNull() {
    return addWhereClause(WhereClause(
      1,
      ['StringValue'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> valueFieldIsNotNull() {
    return addWhereClause(WhereClause(
      1,
      ['StringValue'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> wordsFieldWordEqualTo(
      String? wordsField) {
    return addWhereClause(WhereClause(
      2,
      ['StringWords'],
      upper: [wordsField],
      includeUpper: true,
      lower: [wordsField],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModel, QAfterWhereClause> wordsFieldWordStartsWith(
      String? value) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addWhereClause(WhereClause(
      2,
      ['StringWords'],
      lower: [convertedValue],
      upper: ['$convertedValue\u{FFFFF}'],
      includeLower: true,
      includeUpper: true,
    ));
  }
}

extension FloatModelQueryWhereSort on QueryBuilder<FloatModel, QWhere> {
  QueryBuilder<FloatModel, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }

  QueryBuilder<FloatModel, QAfterWhere> anyField() {
    return addWhereClause(WhereClause(0, []));
  }
}

extension FloatModelQueryWhere on QueryBuilder<FloatModel, QWhereClause> {
  QueryBuilder<FloatModel, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<FloatModel, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<FloatModel, QAfterWhereClause> idBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<FloatModel, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<FloatModel, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<FloatModel, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<FloatModel, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<FloatModel, QAfterWhereClause> fieldBetween(
      double? lower, double? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      0,
      ['Float'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<FloatModel, QAfterWhereClause> fieldGreaterThan(double? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      0,
      ['Float'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<FloatModel, QAfterWhereClause> fieldLessThan(double? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      0,
      ['Float'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<FloatModel, QAfterWhereClause> fieldIsNull() {
    return addWhereClause(WhereClause(
      0,
      ['Float'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<FloatModel, QAfterWhereClause> fieldIsNotNull() {
    return addWhereClause(WhereClause(
      0,
      ['Float'],
      lower: [null],
      includeLower: false,
    ));
  }
}

extension DateTimeModelQueryWhereSort on QueryBuilder<DateTimeModel, QWhere> {
  QueryBuilder<DateTimeModel, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }

  QueryBuilder<DateTimeModel, QAfterWhere> anyDate() {
    return addWhereClause(WhereClause(0, []));
  }

  QueryBuilder<DateTimeModel, QAfterWhere> anyDateNullable() {
    return addWhereClause(WhereClause(1, []));
  }
}

extension DateTimeModelQueryWhere on QueryBuilder<DateTimeModel, QWhereClause> {
  QueryBuilder<DateTimeModel, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> dateEqualTo(DateTime date) {
    return addWhereClause(WhereClause(
      0,
      ['DateTime'],
      upper: [date],
      includeUpper: true,
      lower: [date],
      includeLower: true,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> dateNotEqualTo(DateTime date) {
    final cloned = addWhereClause(WhereClause(
      0,
      ['DateTime'],
      upper: [date],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      0,
      ['DateTime'],
      lower: [date],
      includeLower: false,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> dateBetween(
      DateTime lower, DateTime upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      0,
      ['DateTime'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> dateNullableEqualTo(
      DateTime? dateNullable) {
    return addWhereClause(WhereClause(
      1,
      ['DateTime'],
      upper: [dateNullable],
      includeUpper: true,
      lower: [dateNullable],
      includeLower: true,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> dateNullableNotEqualTo(
      DateTime? dateNullable) {
    final cloned = addWhereClause(WhereClause(
      1,
      ['DateTime'],
      upper: [dateNullable],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      1,
      ['DateTime'],
      lower: [dateNullable],
      includeLower: false,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> dateNullableBetween(
      DateTime? lower, DateTime? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      1,
      ['DateTime'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> dateNullableIsNull() {
    return addWhereClause(WhereClause(
      1,
      ['DateTime'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterWhereClause> dateNullableIsNotNull() {
    return addWhereClause(WhereClause(
      1,
      ['DateTime'],
      lower: [null],
      includeLower: false,
    ));
  }
}

extension UserModelQueryWhereSort on QueryBuilder<UserModel, QWhere> {
  QueryBuilder<UserModel, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }

  QueryBuilder<UserModel, QAfterWhere> anyAge() {
    return addWhereClause(WhereClause(1, []));
  }
}

extension UserModelQueryWhere on QueryBuilder<UserModel, QWhereClause> {
  QueryBuilder<UserModel, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> idBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> nameEqualTo(String? name) {
    return addWhereClause(WhereClause(
      0,
      ['StringHash'],
      upper: [name],
      includeUpper: true,
      lower: [name],
      includeLower: true,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> nameNotEqualTo(String? name) {
    final cloned = addWhereClause(WhereClause(
      0,
      ['StringHash'],
      upper: [name],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      0,
      ['StringHash'],
      lower: [name],
      includeLower: false,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> nameIsNull() {
    return addWhereClause(WhereClause(
      0,
      ['StringHash'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> nameIsNotNull() {
    return addWhereClause(WhereClause(
      0,
      ['StringHash'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> ageEqualTo(int? age) {
    return addWhereClause(WhereClause(
      1,
      ['Long'],
      upper: [age],
      includeUpper: true,
      lower: [age],
      includeLower: true,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> ageNotEqualTo(int? age) {
    final cloned = addWhereClause(WhereClause(
      1,
      ['Long'],
      upper: [age],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      1,
      ['Long'],
      lower: [age],
      includeLower: false,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> ageBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> ageGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> ageLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> ageIsNull() {
    return addWhereClause(WhereClause(
      1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<UserModel, QAfterWhereClause> ageIsNotNull() {
    return addWhereClause(WhereClause(
      1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }
}

extension LinkModelAQueryWhereSort on QueryBuilder<LinkModelA, QWhere> {
  QueryBuilder<LinkModelA, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }
}

extension LinkModelAQueryWhere on QueryBuilder<LinkModelA, QWhereClause> {
  QueryBuilder<LinkModelA, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<LinkModelA, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<LinkModelA, QAfterWhereClause> idBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<LinkModelA, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<LinkModelA, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<LinkModelA, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<LinkModelA, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }
}

extension LinkModelBQueryWhereSort on QueryBuilder<LinkModelB, QWhere> {
  QueryBuilder<LinkModelB, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }
}

extension LinkModelBQueryWhere on QueryBuilder<LinkModelB, QWhereClause> {
  QueryBuilder<LinkModelB, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<LinkModelB, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<LinkModelB, QAfterWhereClause> idBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<LinkModelB, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<LinkModelB, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<LinkModelB, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<LinkModelB, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }
}

extension ConverterModelQueryWhereSort on QueryBuilder<ConverterModel, QWhere> {
  QueryBuilder<ConverterModel, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }

  QueryBuilder<ConverterModel, QAfterWhere> anyStringValue() {
    return addWhereClause(WhereClause(6, []));
  }
}

extension ConverterModelQueryWhere
    on QueryBuilder<ConverterModel, QWhereClause> {
  QueryBuilder<ConverterModel, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> boolValueEqualTo(
      bool boolValue) {
    return addWhereClause(WhereClause(
      0,
      ['StringHash'],
      upper: [_ConverterModelAdapter._BoolConverter.toIsar(boolValue)],
      includeUpper: true,
      lower: [_ConverterModelAdapter._BoolConverter.toIsar(boolValue)],
      includeLower: true,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> boolValueNotEqualTo(
      bool boolValue) {
    final cloned = addWhereClause(WhereClause(
      0,
      ['StringHash'],
      upper: [_ConverterModelAdapter._BoolConverter.toIsar(boolValue)],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      0,
      ['StringHash'],
      lower: [_ConverterModelAdapter._BoolConverter.toIsar(boolValue)],
      includeLower: false,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> intValueEqualTo(
      int intValue) {
    return addWhereClause(WhereClause(
      1,
      ['StringHash'],
      upper: [_ConverterModelAdapter._IntConverter.toIsar(intValue)],
      includeUpper: true,
      lower: [_ConverterModelAdapter._IntConverter.toIsar(intValue)],
      includeLower: true,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> intValueNotEqualTo(
      int intValue) {
    final cloned = addWhereClause(WhereClause(
      1,
      ['StringHash'],
      upper: [_ConverterModelAdapter._IntConverter.toIsar(intValue)],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      1,
      ['StringHash'],
      lower: [_ConverterModelAdapter._IntConverter.toIsar(intValue)],
      includeLower: false,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> longValueEqualTo(
      int longValue) {
    return addWhereClause(WhereClause(
      2,
      ['StringHash'],
      upper: [_ConverterModelAdapter._IntConverter.toIsar(longValue)],
      includeUpper: true,
      lower: [_ConverterModelAdapter._IntConverter.toIsar(longValue)],
      includeLower: true,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> longValueNotEqualTo(
      int longValue) {
    final cloned = addWhereClause(WhereClause(
      2,
      ['StringHash'],
      upper: [_ConverterModelAdapter._IntConverter.toIsar(longValue)],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      2,
      ['StringHash'],
      lower: [_ConverterModelAdapter._IntConverter.toIsar(longValue)],
      includeLower: false,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> floatValueEqualTo(
      double floatValue) {
    return addWhereClause(WhereClause(
      3,
      ['StringHash'],
      upper: [_ConverterModelAdapter._DoubleConverter.toIsar(floatValue)],
      includeUpper: true,
      lower: [_ConverterModelAdapter._DoubleConverter.toIsar(floatValue)],
      includeLower: true,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> floatValueNotEqualTo(
      double floatValue) {
    final cloned = addWhereClause(WhereClause(
      3,
      ['StringHash'],
      upper: [_ConverterModelAdapter._DoubleConverter.toIsar(floatValue)],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      3,
      ['StringHash'],
      lower: [_ConverterModelAdapter._DoubleConverter.toIsar(floatValue)],
      includeLower: false,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> doubleValueEqualTo(
      double doubleValue) {
    return addWhereClause(WhereClause(
      4,
      ['StringHash'],
      upper: [_ConverterModelAdapter._DoubleConverter.toIsar(doubleValue)],
      includeUpper: true,
      lower: [_ConverterModelAdapter._DoubleConverter.toIsar(doubleValue)],
      includeLower: true,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> doubleValueNotEqualTo(
      double doubleValue) {
    final cloned = addWhereClause(WhereClause(
      4,
      ['StringHash'],
      upper: [_ConverterModelAdapter._DoubleConverter.toIsar(doubleValue)],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      4,
      ['StringHash'],
      lower: [_ConverterModelAdapter._DoubleConverter.toIsar(doubleValue)],
      includeLower: false,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> dateValueEqualTo(
      DateTime dateValue) {
    return addWhereClause(WhereClause(
      5,
      ['StringHash'],
      upper: [_ConverterModelAdapter._DateConverter.toIsar(dateValue)],
      includeUpper: true,
      lower: [_ConverterModelAdapter._DateConverter.toIsar(dateValue)],
      includeLower: true,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> dateValueNotEqualTo(
      DateTime dateValue) {
    final cloned = addWhereClause(WhereClause(
      5,
      ['StringHash'],
      upper: [_ConverterModelAdapter._DateConverter.toIsar(dateValue)],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      5,
      ['StringHash'],
      lower: [_ConverterModelAdapter._DateConverter.toIsar(dateValue)],
      includeLower: false,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> stringValueEqualTo(
      String stringValue) {
    return addWhereClause(WhereClause(
      6,
      ['Long'],
      upper: [_ConverterModelAdapter._StringConverter.toIsar(stringValue)],
      includeUpper: true,
      lower: [_ConverterModelAdapter._StringConverter.toIsar(stringValue)],
      includeLower: true,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> stringValueNotEqualTo(
      String stringValue) {
    final cloned = addWhereClause(WhereClause(
      6,
      ['Long'],
      upper: [_ConverterModelAdapter._StringConverter.toIsar(stringValue)],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      6,
      ['Long'],
      lower: [_ConverterModelAdapter._StringConverter.toIsar(stringValue)],
      includeLower: false,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> stringValueBetween(
      String lower, String upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      6,
      ['Long'],
      upper: [_ConverterModelAdapter._StringConverter.toIsar(upper)],
      includeUpper: includeUpper,
      lower: [_ConverterModelAdapter._StringConverter.toIsar(lower)],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> stringValueGreaterThan(
      String value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      6,
      ['Long'],
      lower: [_ConverterModelAdapter._StringConverter.toIsar(value)],
      includeLower: include,
    ));
  }

  QueryBuilder<ConverterModel, QAfterWhereClause> stringValueLessThan(
      String value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      6,
      ['Long'],
      upper: [_ConverterModelAdapter._StringConverter.toIsar(value)],
      includeUpper: include,
    ));
  }
}

extension MessageQueryWhereSort on QueryBuilder<Message, QWhere> {
  QueryBuilder<Message, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }
}

extension MessageQueryWhere on QueryBuilder<Message, QWhereClause> {
  QueryBuilder<Message, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<Message, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<Message, QAfterWhereClause> idBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<Message, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<Message, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<Message, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<Message, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<Message, QAfterWhereClause> messageEqualTo(String? message) {
    return addWhereClause(WhereClause(
      0,
      ['StringHash'],
      upper: [message],
      includeUpper: true,
      lower: [message],
      includeLower: true,
    ));
  }

  QueryBuilder<Message, QAfterWhereClause> messageNotEqualTo(String? message) {
    final cloned = addWhereClause(WhereClause(
      0,
      ['StringHash'],
      upper: [message],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      0,
      ['StringHash'],
      lower: [message],
      includeLower: false,
    ));
  }

  QueryBuilder<Message, QAfterWhereClause> messageIsNull() {
    return addWhereClause(WhereClause(
      0,
      ['StringHash'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<Message, QAfterWhereClause> messageIsNotNull() {
    return addWhereClause(WhereClause(
      0,
      ['StringHash'],
      lower: [null],
      includeLower: false,
    ));
  }
}

extension StringModelCISQueryWhereSort on QueryBuilder<StringModelCIS, QWhere> {
  QueryBuilder<StringModelCIS, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }

  QueryBuilder<StringModelCIS, QAfterWhere> anyValueField() {
    return addWhereClause(WhereClause(1, []));
  }
}

extension StringModelCISQueryWhere
    on QueryBuilder<StringModelCIS, QWhereClause> {
  QueryBuilder<StringModelCIS, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> hashFieldEqualTo(
      String? hashField) {
    return addWhereClause(WhereClause(
      0,
      ['StringHashLC'],
      upper: [hashField],
      includeUpper: true,
      lower: [hashField],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> hashFieldNotEqualTo(
      String? hashField) {
    final cloned = addWhereClause(WhereClause(
      0,
      ['StringHashLC'],
      upper: [hashField],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      0,
      ['StringHashLC'],
      lower: [hashField],
      includeLower: false,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> hashFieldIsNull() {
    return addWhereClause(WhereClause(
      0,
      ['StringHashLC'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> hashFieldIsNotNull() {
    return addWhereClause(WhereClause(
      0,
      ['StringHashLC'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> valueFieldEqualTo(
      String? valueField) {
    return addWhereClause(WhereClause(
      1,
      ['StringValueLC'],
      upper: [valueField],
      includeUpper: true,
      lower: [valueField],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> valueFieldNotEqualTo(
      String? valueField) {
    final cloned = addWhereClause(WhereClause(
      1,
      ['StringValueLC'],
      upper: [valueField],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      1,
      ['StringValueLC'],
      lower: [valueField],
      includeLower: false,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> valueFieldStartsWith(
      String? value) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addWhereClause(WhereClause(
      1,
      ['StringValueLC'],
      lower: [convertedValue],
      upper: ['$convertedValue\u{FFFFF}'],
      includeLower: true,
      includeUpper: true,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> valueFieldIsNull() {
    return addWhereClause(WhereClause(
      1,
      ['StringValueLC'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> valueFieldIsNotNull() {
    return addWhereClause(WhereClause(
      1,
      ['StringValueLC'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> wordsFieldWordEqualTo(
      String? wordsField) {
    return addWhereClause(WhereClause(
      2,
      ['StringWordsLC'],
      upper: [wordsField],
      includeUpper: true,
      lower: [wordsField],
      includeLower: true,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterWhereClause> wordsFieldWordStartsWith(
      String? value) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addWhereClause(WhereClause(
      2,
      ['StringWordsLC'],
      lower: [convertedValue],
      upper: ['$convertedValue\u{FFFFF}'],
      includeLower: true,
      includeUpper: true,
    ));
  }
}

extension DoubleModelQueryWhereSort on QueryBuilder<DoubleModel, QWhere> {
  QueryBuilder<DoubleModel, QAfterWhere> anyId() {
    return addWhereClause(WhereClause(-1, []));
  }

  QueryBuilder<DoubleModel, QAfterWhere> anyField() {
    return addWhereClause(WhereClause(0, []));
  }
}

extension DoubleModelQueryWhere on QueryBuilder<DoubleModel, QWhereClause> {
  QueryBuilder<DoubleModel, QAfterWhereClause> idEqualTo(int? id) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: true,
      lower: [id],
      includeLower: true,
    ));
  }

  QueryBuilder<DoubleModel, QAfterWhereClause> idNotEqualTo(int? id) {
    final cloned = addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [id],
      includeUpper: false,
    ));
    return cloned.addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [id],
      includeLower: false,
    ));
  }

  QueryBuilder<DoubleModel, QAfterWhereClause> idBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<DoubleModel, QAfterWhereClause> idGreaterThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<DoubleModel, QAfterWhereClause> idLessThan(int? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<DoubleModel, QAfterWhereClause> idIsNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<DoubleModel, QAfterWhereClause> idIsNotNull() {
    return addWhereClause(WhereClause(
      -1,
      ['Long'],
      lower: [null],
      includeLower: false,
    ));
  }

  QueryBuilder<DoubleModel, QAfterWhereClause> fieldBetween(
      double? lower, double? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addWhereClause(WhereClause(
      0,
      ['Double'],
      upper: [upper],
      includeUpper: includeUpper,
      lower: [lower],
      includeLower: includeLower,
    ));
  }

  QueryBuilder<DoubleModel, QAfterWhereClause> fieldGreaterThan(double? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      0,
      ['Double'],
      lower: [value],
      includeLower: include,
    ));
  }

  QueryBuilder<DoubleModel, QAfterWhereClause> fieldLessThan(double? value,
      {bool include = false}) {
    return addWhereClause(WhereClause(
      0,
      ['Double'],
      upper: [value],
      includeUpper: include,
    ));
  }

  QueryBuilder<DoubleModel, QAfterWhereClause> fieldIsNull() {
    return addWhereClause(WhereClause(
      0,
      ['Double'],
      upper: [null],
      includeUpper: true,
      lower: [null],
      includeLower: true,
    ));
  }

  QueryBuilder<DoubleModel, QAfterWhereClause> fieldIsNotNull() {
    return addWhereClause(WhereClause(
      0,
      ['Double'],
      lower: [null],
      includeLower: false,
    ));
  }
}

extension BoolModelQueryFilter on QueryBuilder<BoolModel, QFilterCondition> {
  QueryBuilder<BoolModel, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<BoolModel, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<BoolModel, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<BoolModel, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<BoolModel, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<BoolModel, QAfterFilterCondition> fieldIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'Bool',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<BoolModel, QAfterFilterCondition> fieldEqualTo(bool? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'Bool',
      lower: value,
      upper: value,
    ));
  }
}

extension LongModelQueryFilter on QueryBuilder<LongModel, QFilterCondition> {
  QueryBuilder<LongModel, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<LongModel, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<LongModel, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<LongModel, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<LongModel, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<LongModel, QAfterFilterCondition> fieldIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<LongModel, QAfterFilterCondition> fieldEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<LongModel, QAfterFilterCondition> fieldGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      1,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<LongModel, QAfterFilterCondition> fieldLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      1,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<LongModel, QAfterFilterCondition> fieldBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      1,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }
}

extension MultiTypeModelQueryFilter
    on QueryBuilder<MultiTypeModel, QFilterCondition> {
  QueryBuilder<MultiTypeModel, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> boolValueIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'Bool',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> boolValueEqualTo(
      bool? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'Bool',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> intValueIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      2,
      'Int',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> intValueEqualTo(
      int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      2,
      'Int',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> intValueGreaterThan(
      int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      2,
      'Int',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> intValueLessThan(
      int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      2,
      'Int',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> intValueBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      2,
      'Int',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> floatValueIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      3,
      'Float',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> floatValueGreaterThan(
      double? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      3,
      'Float',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> floatValueLessThan(
      double? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      3,
      'Float',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> floatValueBetween(
      double? lower, double? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      3,
      'Float',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> longValueIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      4,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> longValueEqualTo(
      int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      4,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> longValueGreaterThan(
      int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      4,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> longValueLessThan(
      int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      4,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> longValueBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      4,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> doubleValueIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      5,
      'Double',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> doubleValueGreaterThan(
      double? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      5,
      'Double',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> doubleValueLessThan(
      double? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      5,
      'Double',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> doubleValueBetween(
      double? lower, double? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      5,
      'Double',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> dateTimeValueIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      6,
      'DateTime',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> dateTimeValueEqualTo(
      DateTime? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      6,
      'DateTime',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> dateTimeValueGreaterThan(
      DateTime? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      6,
      'DateTime',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> dateTimeValueLessThan(
      DateTime? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      6,
      'DateTime',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> dateTimeValueBetween(
      DateTime? lower, DateTime? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      6,
      'DateTime',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> stringValueIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      7,
      'String',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> stringValueEqualTo(
      String? value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      7,
      'String',
      lower: value,
      upper: value,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> stringValueStartsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      7,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> stringValueEndsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      7,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> stringValueContains(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      7,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<MultiTypeModel, QAfterFilterCondition> stringValueMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      7,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }
}

extension IntModelQueryFilter on QueryBuilder<IntModel, QFilterCondition> {
  QueryBuilder<IntModel, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<IntModel, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<IntModel, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<IntModel, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<IntModel, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<IntModel, QAfterFilterCondition> fieldIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'Int',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<IntModel, QAfterFilterCondition> fieldEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'Int',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<IntModel, QAfterFilterCondition> fieldGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      1,
      'Int',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<IntModel, QAfterFilterCondition> fieldLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      1,
      'Int',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<IntModel, QAfterFilterCondition> fieldBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      1,
      'Int',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }
}

extension StringModelQueryFilter
    on QueryBuilder<StringModel, QFilterCondition> {
  QueryBuilder<StringModel, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> hashFieldIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'String',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> hashFieldEqualTo(
      String? value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'String',
      lower: value,
      upper: value,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> hashFieldStartsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> hashFieldEndsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> hashFieldContains(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> hashFieldMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      1,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> valueFieldIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      2,
      'String',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> valueFieldEqualTo(
      String? value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      2,
      'String',
      lower: value,
      upper: value,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> valueFieldStartsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      2,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> valueFieldEndsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      2,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> valueFieldContains(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      2,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> valueFieldMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      2,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> wordsFieldIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      3,
      'String',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> wordsFieldEqualTo(
      String? value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      3,
      'String',
      lower: value,
      upper: value,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> wordsFieldStartsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      3,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> wordsFieldEndsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      3,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> wordsFieldContains(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      3,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModel, QAfterFilterCondition> wordsFieldMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      3,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }
}

extension FloatModelQueryFilter on QueryBuilder<FloatModel, QFilterCondition> {
  QueryBuilder<FloatModel, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<FloatModel, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<FloatModel, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<FloatModel, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<FloatModel, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<FloatModel, QAfterFilterCondition> fieldIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'Float',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<FloatModel, QAfterFilterCondition> fieldGreaterThan(
      double? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      1,
      'Float',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<FloatModel, QAfterFilterCondition> fieldLessThan(double? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      1,
      'Float',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<FloatModel, QAfterFilterCondition> fieldBetween(
      double? lower, double? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      1,
      'Float',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }
}

extension DateTimeModelQueryFilter
    on QueryBuilder<DateTimeModel, QFilterCondition> {
  QueryBuilder<DateTimeModel, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> dateEqualTo(
      DateTime value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'DateTime',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> dateGreaterThan(
      DateTime value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      1,
      'DateTime',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> dateLessThan(
      DateTime value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      1,
      'DateTime',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> dateBetween(
      DateTime lower, DateTime upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      1,
      'DateTime',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> dateNullableIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      2,
      'DateTime',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> dateNullableEqualTo(
      DateTime? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      2,
      'DateTime',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> dateNullableGreaterThan(
      DateTime? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      2,
      'DateTime',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> dateNullableLessThan(
      DateTime? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      2,
      'DateTime',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<DateTimeModel, QAfterFilterCondition> dateNullableBetween(
      DateTime? lower, DateTime? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      2,
      'DateTime',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }
}

extension UserModelQueryFilter on QueryBuilder<UserModel, QFilterCondition> {
  QueryBuilder<UserModel, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> nameIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'String',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> nameEqualTo(String? value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'String',
      lower: value,
      upper: value,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> nameStartsWith(String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> nameEndsWith(String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> nameContains(String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> nameMatches(String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      1,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> ageIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      2,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> ageEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      2,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> ageGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      2,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> ageLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      2,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> ageBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      2,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<UserModel, QAfterFilterCondition> adminEqualTo(bool value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      3,
      'Bool',
      lower: value,
      upper: value,
    ));
  }
}

extension LinkModelAQueryFilter on QueryBuilder<LinkModelA, QFilterCondition> {
  QueryBuilder<LinkModelA, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> nameEqualTo(String value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'String',
      lower: value,
      upper: value,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> nameStartsWith(String value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> nameEndsWith(String value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> nameContains(String value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> nameMatches(String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      1,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }
}

extension LinkModelBQueryFilter on QueryBuilder<LinkModelB, QFilterCondition> {
  QueryBuilder<LinkModelB, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<LinkModelB, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<LinkModelB, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<LinkModelB, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<LinkModelB, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<LinkModelB, QAfterFilterCondition> nameEqualTo(String value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'String',
      lower: value,
      upper: value,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<LinkModelB, QAfterFilterCondition> nameStartsWith(String value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<LinkModelB, QAfterFilterCondition> nameEndsWith(String value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<LinkModelB, QAfterFilterCondition> nameContains(String value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<LinkModelB, QAfterFilterCondition> nameMatches(String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      1,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }
}

extension ConverterModelQueryFilter
    on QueryBuilder<ConverterModel, QFilterCondition> {
  QueryBuilder<ConverterModel, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> boolValueEqualTo(
      bool value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'String',
      lower: _ConverterModelAdapter._BoolConverter.toIsar(value),
      upper: _ConverterModelAdapter._BoolConverter.toIsar(value),
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> boolValueStartsWith(
      bool value,
      {bool caseSensitive = true}) {
    final convertedValue = _ConverterModelAdapter._BoolConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> boolValueEndsWith(
      bool value,
      {bool caseSensitive = true}) {
    final convertedValue = _ConverterModelAdapter._BoolConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> boolValueContains(
      bool value,
      {bool caseSensitive = true}) {
    final convertedValue = _ConverterModelAdapter._BoolConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> boolValueMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      1,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> intValueEqualTo(int value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      2,
      'String',
      lower: _ConverterModelAdapter._IntConverter.toIsar(value),
      upper: _ConverterModelAdapter._IntConverter.toIsar(value),
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> intValueStartsWith(
      int value,
      {bool caseSensitive = true}) {
    final convertedValue = _ConverterModelAdapter._IntConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      2,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> intValueEndsWith(
      int value,
      {bool caseSensitive = true}) {
    final convertedValue = _ConverterModelAdapter._IntConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      2,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> intValueContains(
      int value,
      {bool caseSensitive = true}) {
    final convertedValue = _ConverterModelAdapter._IntConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      2,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> intValueMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      2,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> longValueEqualTo(
      int value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      3,
      'String',
      lower: _ConverterModelAdapter._IntConverter.toIsar(value),
      upper: _ConverterModelAdapter._IntConverter.toIsar(value),
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> longValueStartsWith(
      int value,
      {bool caseSensitive = true}) {
    final convertedValue = _ConverterModelAdapter._IntConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      3,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> longValueEndsWith(
      int value,
      {bool caseSensitive = true}) {
    final convertedValue = _ConverterModelAdapter._IntConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      3,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> longValueContains(
      int value,
      {bool caseSensitive = true}) {
    final convertedValue = _ConverterModelAdapter._IntConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      3,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> longValueMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      3,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> floatValueEqualTo(
      double value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      4,
      'String',
      lower: _ConverterModelAdapter._DoubleConverter.toIsar(value),
      upper: _ConverterModelAdapter._DoubleConverter.toIsar(value),
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> floatValueStartsWith(
      double value,
      {bool caseSensitive = true}) {
    final convertedValue =
        _ConverterModelAdapter._DoubleConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      4,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> floatValueEndsWith(
      double value,
      {bool caseSensitive = true}) {
    final convertedValue =
        _ConverterModelAdapter._DoubleConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      4,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> floatValueContains(
      double value,
      {bool caseSensitive = true}) {
    final convertedValue =
        _ConverterModelAdapter._DoubleConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      4,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> floatValueMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      4,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> doubleValueEqualTo(
      double value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      5,
      'String',
      lower: _ConverterModelAdapter._DoubleConverter.toIsar(value),
      upper: _ConverterModelAdapter._DoubleConverter.toIsar(value),
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> doubleValueStartsWith(
      double value,
      {bool caseSensitive = true}) {
    final convertedValue =
        _ConverterModelAdapter._DoubleConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      5,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> doubleValueEndsWith(
      double value,
      {bool caseSensitive = true}) {
    final convertedValue =
        _ConverterModelAdapter._DoubleConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      5,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> doubleValueContains(
      double value,
      {bool caseSensitive = true}) {
    final convertedValue =
        _ConverterModelAdapter._DoubleConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      5,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> doubleValueMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      5,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> dateValueEqualTo(
      DateTime value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      6,
      'String',
      lower: _ConverterModelAdapter._DateConverter.toIsar(value),
      upper: _ConverterModelAdapter._DateConverter.toIsar(value),
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> dateValueStartsWith(
      DateTime value,
      {bool caseSensitive = true}) {
    final convertedValue = _ConverterModelAdapter._DateConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      6,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> dateValueEndsWith(
      DateTime value,
      {bool caseSensitive = true}) {
    final convertedValue = _ConverterModelAdapter._DateConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      6,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> dateValueContains(
      DateTime value,
      {bool caseSensitive = true}) {
    final convertedValue = _ConverterModelAdapter._DateConverter.toIsar(value);
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      6,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> dateValueMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      6,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> stringValueEqualTo(
      String value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      7,
      'Long',
      lower: _ConverterModelAdapter._StringConverter.toIsar(value),
      upper: _ConverterModelAdapter._StringConverter.toIsar(value),
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> stringValueGreaterThan(
      String value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      7,
      'Long',
      lower: _ConverterModelAdapter._StringConverter.toIsar(value),
      includeLower: include,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> stringValueLessThan(
      String value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      7,
      'Long',
      upper: _ConverterModelAdapter._StringConverter.toIsar(value),
      includeUpper: include,
    ));
  }

  QueryBuilder<ConverterModel, QAfterFilterCondition> stringValueBetween(
      String lower, String upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      7,
      'Long',
      lower: _ConverterModelAdapter._StringConverter.toIsar(lower),
      includeLower: includeLower,
      upper: _ConverterModelAdapter._StringConverter.toIsar(upper),
      includeUpper: includeUpper,
    ));
  }
}

extension MessageQueryFilter on QueryBuilder<Message, QFilterCondition> {
  QueryBuilder<Message, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<Message, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<Message, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<Message, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<Message, QAfterFilterCondition> idBetween(int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<Message, QAfterFilterCondition> messageIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'String',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<Message, QAfterFilterCondition> messageEqualTo(String? value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'String',
      lower: value,
      upper: value,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<Message, QAfterFilterCondition> messageStartsWith(String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<Message, QAfterFilterCondition> messageEndsWith(String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<Message, QAfterFilterCondition> messageContains(String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<Message, QAfterFilterCondition> messageMatches(String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      1,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }
}

extension StringModelCISQueryFilter
    on QueryBuilder<StringModelCIS, QFilterCondition> {
  QueryBuilder<StringModelCIS, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> hashFieldIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'String',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> hashFieldEqualTo(
      String? value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'String',
      lower: value,
      upper: value,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> hashFieldStartsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> hashFieldEndsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> hashFieldContains(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      1,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> hashFieldMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      1,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> valueFieldIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      2,
      'String',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> valueFieldEqualTo(
      String? value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      2,
      'String',
      lower: value,
      upper: value,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> valueFieldStartsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      2,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> valueFieldEndsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      2,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> valueFieldContains(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      2,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> valueFieldMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      2,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> wordsFieldIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      3,
      'String',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> wordsFieldEqualTo(
      String? value,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      3,
      'String',
      lower: value,
      upper: value,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> wordsFieldStartsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.StartsWith,
      3,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> wordsFieldEndsWith(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.EndsWith,
      3,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> wordsFieldContains(
      String? value,
      {bool caseSensitive = true}) {
    final convertedValue = value;
    assert(convertedValue != null, 'Null values are not allowed');
    return addFilterCondition(QueryCondition(
      ConditionType.Contains,
      3,
      'String',
      lower: convertedValue,
      caseSensitive: caseSensitive,
    ));
  }

  QueryBuilder<StringModelCIS, QAfterFilterCondition> wordsFieldMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Matches,
      3,
      'String',
      lower: pattern,
      caseSensitive: caseSensitive,
    ));
  }
}

extension DoubleModelQueryFilter
    on QueryBuilder<DoubleModel, QFilterCondition> {
  QueryBuilder<DoubleModel, QAfterFilterCondition> idIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<DoubleModel, QAfterFilterCondition> idEqualTo(int? value) {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      0,
      'Long',
      lower: value,
      upper: value,
    ));
  }

  QueryBuilder<DoubleModel, QAfterFilterCondition> idGreaterThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      0,
      'Long',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<DoubleModel, QAfterFilterCondition> idLessThan(int? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      0,
      'Long',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<DoubleModel, QAfterFilterCondition> idBetween(
      int? lower, int? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      0,
      'Long',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }

  QueryBuilder<DoubleModel, QAfterFilterCondition> fieldIsNull() {
    return addFilterCondition(QueryCondition(
      ConditionType.Eq,
      1,
      'Double',
      lower: null,
      upper: null,
    ));
  }

  QueryBuilder<DoubleModel, QAfterFilterCondition> fieldGreaterThan(
      double? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Gt,
      1,
      'Double',
      lower: value,
      includeLower: include,
    ));
  }

  QueryBuilder<DoubleModel, QAfterFilterCondition> fieldLessThan(double? value,
      {bool include = false}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Lt,
      1,
      'Double',
      upper: value,
      includeUpper: include,
    ));
  }

  QueryBuilder<DoubleModel, QAfterFilterCondition> fieldBetween(
      double? lower, double? upper,
      {bool includeLower = true, bool includeUpper = true}) {
    return addFilterCondition(QueryCondition(
      ConditionType.Between,
      1,
      'Double',
      lower: lower,
      includeLower: includeLower,
      upper: upper,
      includeUpper: includeUpper,
    ));
  }
}

extension BoolModelQueryLinks on QueryBuilder<BoolModel, QFilterCondition> {}

extension LongModelQueryLinks on QueryBuilder<LongModel, QFilterCondition> {}

extension MultiTypeModelQueryLinks
    on QueryBuilder<MultiTypeModel, QFilterCondition> {}

extension IntModelQueryLinks on QueryBuilder<IntModel, QFilterCondition> {}

extension StringModelQueryLinks on QueryBuilder<StringModel, QFilterCondition> {
}

extension FloatModelQueryLinks on QueryBuilder<FloatModel, QFilterCondition> {}

extension DateTimeModelQueryLinks
    on QueryBuilder<DateTimeModel, QFilterCondition> {}

extension UserModelQueryLinks on QueryBuilder<UserModel, QFilterCondition> {}

extension LinkModelAQueryLinks on QueryBuilder<LinkModelA, QFilterCondition> {
  QueryBuilder<LinkModelA, QAfterFilterCondition> selfLink(
      FilterQuery<LinkModelA> q) {
    return linkInternal(
      isar.linkModelAs,
      q,
      0,
      false,
    );
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> otherLink(
      FilterQuery<LinkModelB> q) {
    return linkInternal(
      isar.linkModelBs,
      q,
      1,
      false,
    );
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> selfLinks(
      FilterQuery<LinkModelA> q) {
    return linkInternal(
      isar.linkModelAs,
      q,
      2,
      false,
    );
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> otherLinks(
      FilterQuery<LinkModelB> q) {
    return linkInternal(
      isar.linkModelBs,
      q,
      3,
      false,
    );
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> selfLinkBacklink(
      FilterQuery<LinkModelA> q) {
    return linkInternal(
      isar.linkModelAs,
      q,
      0,
      true,
    );
  }

  QueryBuilder<LinkModelA, QAfterFilterCondition> selfLinksBacklink(
      FilterQuery<LinkModelA> q) {
    return linkInternal(
      isar.linkModelAs,
      q,
      2,
      true,
    );
  }
}

extension LinkModelBQueryLinks on QueryBuilder<LinkModelB, QFilterCondition> {
  QueryBuilder<LinkModelB, QAfterFilterCondition> linkBacklinks(
      FilterQuery<LinkModelA> q) {
    return linkInternal(
      isar.linkModelAs,
      q,
      1,
      true,
    );
  }

  QueryBuilder<LinkModelB, QAfterFilterCondition> linksBacklinks(
      FilterQuery<LinkModelA> q) {
    return linkInternal(
      isar.linkModelAs,
      q,
      3,
      true,
    );
  }
}

extension ConverterModelQueryLinks
    on QueryBuilder<ConverterModel, QFilterCondition> {}

extension MessageQueryLinks on QueryBuilder<Message, QFilterCondition> {}

extension StringModelCISQueryLinks
    on QueryBuilder<StringModelCIS, QFilterCondition> {}

extension DoubleModelQueryLinks on QueryBuilder<DoubleModel, QFilterCondition> {
}

extension BoolModelQueryWhereSortBy on QueryBuilder<BoolModel, QSortBy> {}

extension BoolModelQueryWhereSortThenBy
    on QueryBuilder<BoolModel, QSortThenBy> {}

extension LongModelQueryWhereSortBy on QueryBuilder<LongModel, QSortBy> {}

extension LongModelQueryWhereSortThenBy
    on QueryBuilder<LongModel, QSortThenBy> {}

extension MultiTypeModelQueryWhereSortBy
    on QueryBuilder<MultiTypeModel, QSortBy> {}

extension MultiTypeModelQueryWhereSortThenBy
    on QueryBuilder<MultiTypeModel, QSortThenBy> {}

extension IntModelQueryWhereSortBy on QueryBuilder<IntModel, QSortBy> {}

extension IntModelQueryWhereSortThenBy on QueryBuilder<IntModel, QSortThenBy> {}

extension StringModelQueryWhereSortBy on QueryBuilder<StringModel, QSortBy> {}

extension StringModelQueryWhereSortThenBy
    on QueryBuilder<StringModel, QSortThenBy> {}

extension FloatModelQueryWhereSortBy on QueryBuilder<FloatModel, QSortBy> {}

extension FloatModelQueryWhereSortThenBy
    on QueryBuilder<FloatModel, QSortThenBy> {}

extension DateTimeModelQueryWhereSortBy
    on QueryBuilder<DateTimeModel, QSortBy> {}

extension DateTimeModelQueryWhereSortThenBy
    on QueryBuilder<DateTimeModel, QSortThenBy> {}

extension UserModelQueryWhereSortBy on QueryBuilder<UserModel, QSortBy> {}

extension UserModelQueryWhereSortThenBy
    on QueryBuilder<UserModel, QSortThenBy> {}

extension LinkModelAQueryWhereSortBy on QueryBuilder<LinkModelA, QSortBy> {}

extension LinkModelAQueryWhereSortThenBy
    on QueryBuilder<LinkModelA, QSortThenBy> {}

extension LinkModelBQueryWhereSortBy on QueryBuilder<LinkModelB, QSortBy> {}

extension LinkModelBQueryWhereSortThenBy
    on QueryBuilder<LinkModelB, QSortThenBy> {}

extension ConverterModelQueryWhereSortBy
    on QueryBuilder<ConverterModel, QSortBy> {}

extension ConverterModelQueryWhereSortThenBy
    on QueryBuilder<ConverterModel, QSortThenBy> {}

extension MessageQueryWhereSortBy on QueryBuilder<Message, QSortBy> {}

extension MessageQueryWhereSortThenBy on QueryBuilder<Message, QSortThenBy> {}

extension StringModelCISQueryWhereSortBy
    on QueryBuilder<StringModelCIS, QSortBy> {}

extension StringModelCISQueryWhereSortThenBy
    on QueryBuilder<StringModelCIS, QSortThenBy> {}

extension DoubleModelQueryWhereSortBy on QueryBuilder<DoubleModel, QSortBy> {}

extension DoubleModelQueryWhereSortThenBy
    on QueryBuilder<DoubleModel, QSortThenBy> {}

extension BoolModelQueryWhereDistinct on QueryBuilder<BoolModel, QDistinct> {
  QueryBuilder<BoolModel, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<BoolModel, QDistinct> distinctByField() {
    return addDistinctByInternal(1);
  }
}

extension LongModelQueryWhereDistinct on QueryBuilder<LongModel, QDistinct> {
  QueryBuilder<LongModel, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<LongModel, QDistinct> distinctByField() {
    return addDistinctByInternal(1);
  }
}

extension MultiTypeModelQueryWhereDistinct
    on QueryBuilder<MultiTypeModel, QDistinct> {
  QueryBuilder<MultiTypeModel, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<MultiTypeModel, QDistinct> distinctByBoolValue() {
    return addDistinctByInternal(1);
  }

  QueryBuilder<MultiTypeModel, QDistinct> distinctByIntValue() {
    return addDistinctByInternal(2);
  }

  QueryBuilder<MultiTypeModel, QDistinct> distinctByFloatValue() {
    return addDistinctByInternal(3);
  }

  QueryBuilder<MultiTypeModel, QDistinct> distinctByLongValue() {
    return addDistinctByInternal(4);
  }

  QueryBuilder<MultiTypeModel, QDistinct> distinctByDoubleValue() {
    return addDistinctByInternal(5);
  }

  QueryBuilder<MultiTypeModel, QDistinct> distinctByDateTimeValue() {
    return addDistinctByInternal(6);
  }

  QueryBuilder<MultiTypeModel, QDistinct> distinctByStringValue(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(7, caseSensitive: caseSensitive);
  }
}

extension IntModelQueryWhereDistinct on QueryBuilder<IntModel, QDistinct> {
  QueryBuilder<IntModel, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<IntModel, QDistinct> distinctByField() {
    return addDistinctByInternal(1);
  }
}

extension StringModelQueryWhereDistinct
    on QueryBuilder<StringModel, QDistinct> {
  QueryBuilder<StringModel, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<StringModel, QDistinct> distinctByHashField(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(1, caseSensitive: caseSensitive);
  }

  QueryBuilder<StringModel, QDistinct> distinctByValueField(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(2, caseSensitive: caseSensitive);
  }

  QueryBuilder<StringModel, QDistinct> distinctByWordsField(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(3, caseSensitive: caseSensitive);
  }
}

extension FloatModelQueryWhereDistinct on QueryBuilder<FloatModel, QDistinct> {
  QueryBuilder<FloatModel, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<FloatModel, QDistinct> distinctByField() {
    return addDistinctByInternal(1);
  }
}

extension DateTimeModelQueryWhereDistinct
    on QueryBuilder<DateTimeModel, QDistinct> {
  QueryBuilder<DateTimeModel, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<DateTimeModel, QDistinct> distinctByDate() {
    return addDistinctByInternal(1);
  }

  QueryBuilder<DateTimeModel, QDistinct> distinctByDateNullable() {
    return addDistinctByInternal(2);
  }
}

extension UserModelQueryWhereDistinct on QueryBuilder<UserModel, QDistinct> {
  QueryBuilder<UserModel, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<UserModel, QDistinct> distinctByName(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(1, caseSensitive: caseSensitive);
  }

  QueryBuilder<UserModel, QDistinct> distinctByAge() {
    return addDistinctByInternal(2);
  }

  QueryBuilder<UserModel, QDistinct> distinctByAdmin() {
    return addDistinctByInternal(3);
  }
}

extension LinkModelAQueryWhereDistinct on QueryBuilder<LinkModelA, QDistinct> {
  QueryBuilder<LinkModelA, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<LinkModelA, QDistinct> distinctByName(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(1, caseSensitive: caseSensitive);
  }
}

extension LinkModelBQueryWhereDistinct on QueryBuilder<LinkModelB, QDistinct> {
  QueryBuilder<LinkModelB, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<LinkModelB, QDistinct> distinctByName(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(1, caseSensitive: caseSensitive);
  }
}

extension ConverterModelQueryWhereDistinct
    on QueryBuilder<ConverterModel, QDistinct> {
  QueryBuilder<ConverterModel, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<ConverterModel, QDistinct> distinctByBoolValue(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(1, caseSensitive: caseSensitive);
  }

  QueryBuilder<ConverterModel, QDistinct> distinctByIntValue(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(2, caseSensitive: caseSensitive);
  }

  QueryBuilder<ConverterModel, QDistinct> distinctByLongValue(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(3, caseSensitive: caseSensitive);
  }

  QueryBuilder<ConverterModel, QDistinct> distinctByFloatValue(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(4, caseSensitive: caseSensitive);
  }

  QueryBuilder<ConverterModel, QDistinct> distinctByDoubleValue(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(5, caseSensitive: caseSensitive);
  }

  QueryBuilder<ConverterModel, QDistinct> distinctByDateValue(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(6, caseSensitive: caseSensitive);
  }

  QueryBuilder<ConverterModel, QDistinct> distinctByStringValue() {
    return addDistinctByInternal(7);
  }
}

extension MessageQueryWhereDistinct on QueryBuilder<Message, QDistinct> {
  QueryBuilder<Message, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<Message, QDistinct> distinctByMessage(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(1, caseSensitive: caseSensitive);
  }
}

extension StringModelCISQueryWhereDistinct
    on QueryBuilder<StringModelCIS, QDistinct> {
  QueryBuilder<StringModelCIS, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<StringModelCIS, QDistinct> distinctByHashField(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(1, caseSensitive: caseSensitive);
  }

  QueryBuilder<StringModelCIS, QDistinct> distinctByValueField(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(2, caseSensitive: caseSensitive);
  }

  QueryBuilder<StringModelCIS, QDistinct> distinctByWordsField(
      {bool caseSensitive = true}) {
    return addDistinctByInternal(3, caseSensitive: caseSensitive);
  }
}

extension DoubleModelQueryWhereDistinct
    on QueryBuilder<DoubleModel, QDistinct> {
  QueryBuilder<DoubleModel, QDistinct> distinctById() {
    return addDistinctByInternal(0);
  }

  QueryBuilder<DoubleModel, QDistinct> distinctByField() {
    return addDistinctByInternal(1);
  }
}

extension BoolModelQueryProperty on QueryBuilder<BoolModel, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<bool?, QQueryOperations> fieldProperty() {
    return addPropertyIndex(1);
  }
}

extension LongModelQueryProperty on QueryBuilder<LongModel, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<int?, QQueryOperations> fieldProperty() {
    return addPropertyIndex(1);
  }
}

extension MultiTypeModelQueryProperty
    on QueryBuilder<MultiTypeModel, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<bool?, QQueryOperations> boolValueProperty() {
    return addPropertyIndex(1);
  }

  QueryBuilder<int?, QQueryOperations> intValueProperty() {
    return addPropertyIndex(2);
  }

  QueryBuilder<double?, QQueryOperations> floatValueProperty() {
    return addPropertyIndex(3);
  }

  QueryBuilder<int?, QQueryOperations> longValueProperty() {
    return addPropertyIndex(4);
  }

  QueryBuilder<double?, QQueryOperations> doubleValueProperty() {
    return addPropertyIndex(5);
  }

  QueryBuilder<DateTime?, QQueryOperations> dateTimeValueProperty() {
    return addPropertyIndex(6);
  }

  QueryBuilder<String?, QQueryOperations> stringValueProperty() {
    return addPropertyIndex(7);
  }

  QueryBuilder<Uint8List?, QQueryOperations> bytesValueProperty() {
    return addPropertyIndex(8);
  }

  QueryBuilder<List<bool>?, QQueryOperations> boolListProperty() {
    return addPropertyIndex(9);
  }

  QueryBuilder<List<int>?, QQueryOperations> intListProperty() {
    return addPropertyIndex(10);
  }

  QueryBuilder<List<double>?, QQueryOperations> floatListProperty() {
    return addPropertyIndex(11);
  }

  QueryBuilder<List<int>?, QQueryOperations> longListProperty() {
    return addPropertyIndex(12);
  }

  QueryBuilder<List<double>?, QQueryOperations> doubleListProperty() {
    return addPropertyIndex(13);
  }

  QueryBuilder<List<DateTime>?, QQueryOperations> dateTimeListValueProperty() {
    return addPropertyIndex(14);
  }

  QueryBuilder<List<String>?, QQueryOperations> stringListProperty() {
    return addPropertyIndex(15);
  }
}

extension IntModelQueryProperty on QueryBuilder<IntModel, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<int?, QQueryOperations> fieldProperty() {
    return addPropertyIndex(1);
  }
}

extension StringModelQueryProperty
    on QueryBuilder<StringModel, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<String?, QQueryOperations> hashFieldProperty() {
    return addPropertyIndex(1);
  }

  QueryBuilder<String?, QQueryOperations> valueFieldProperty() {
    return addPropertyIndex(2);
  }

  QueryBuilder<String?, QQueryOperations> wordsFieldProperty() {
    return addPropertyIndex(3);
  }
}

extension FloatModelQueryProperty on QueryBuilder<FloatModel, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<double?, QQueryOperations> fieldProperty() {
    return addPropertyIndex(1);
  }
}

extension DateTimeModelQueryProperty
    on QueryBuilder<DateTimeModel, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<DateTime, QQueryOperations> dateProperty() {
    return addPropertyIndex(1);
  }

  QueryBuilder<DateTime?, QQueryOperations> dateNullableProperty() {
    return addPropertyIndex(2);
  }

  QueryBuilder<List<DateTime>, QQueryOperations> listProperty() {
    return addPropertyIndex(3);
  }

  QueryBuilder<List<DateTime>?, QQueryOperations> listNullableProperty() {
    return addPropertyIndex(4);
  }

  QueryBuilder<List<DateTime?>, QQueryOperations>
      listElementNullableProperty() {
    return addPropertyIndex(5);
  }

  QueryBuilder<List<DateTime?>?, QQueryOperations>
      listNullableElementNullableProperty() {
    return addPropertyIndex(6);
  }
}

extension UserModelQueryProperty on QueryBuilder<UserModel, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<String?, QQueryOperations> nameProperty() {
    return addPropertyIndex(1);
  }

  QueryBuilder<int?, QQueryOperations> ageProperty() {
    return addPropertyIndex(2);
  }

  QueryBuilder<bool, QQueryOperations> adminProperty() {
    return addPropertyIndex(3);
  }
}

extension LinkModelAQueryProperty on QueryBuilder<LinkModelA, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<String, QQueryOperations> nameProperty() {
    return addPropertyIndex(1);
  }
}

extension LinkModelBQueryProperty on QueryBuilder<LinkModelB, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<String, QQueryOperations> nameProperty() {
    return addPropertyIndex(1);
  }
}

extension ConverterModelQueryProperty
    on QueryBuilder<ConverterModel, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<bool, QQueryOperations> boolValueProperty() {
    return addPropertyIndex(1);
  }

  QueryBuilder<int, QQueryOperations> intValueProperty() {
    return addPropertyIndex(2);
  }

  QueryBuilder<int, QQueryOperations> longValueProperty() {
    return addPropertyIndex(3);
  }

  QueryBuilder<double, QQueryOperations> floatValueProperty() {
    return addPropertyIndex(4);
  }

  QueryBuilder<double, QQueryOperations> doubleValueProperty() {
    return addPropertyIndex(5);
  }

  QueryBuilder<DateTime, QQueryOperations> dateValueProperty() {
    return addPropertyIndex(6);
  }

  QueryBuilder<String, QQueryOperations> stringValueProperty() {
    return addPropertyIndex(7);
  }
}

extension MessageQueryProperty on QueryBuilder<Message, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<String?, QQueryOperations> messageProperty() {
    return addPropertyIndex(1);
  }
}

extension StringModelCISQueryProperty
    on QueryBuilder<StringModelCIS, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<String?, QQueryOperations> hashFieldProperty() {
    return addPropertyIndex(1);
  }

  QueryBuilder<String?, QQueryOperations> valueFieldProperty() {
    return addPropertyIndex(2);
  }

  QueryBuilder<String?, QQueryOperations> wordsFieldProperty() {
    return addPropertyIndex(3);
  }
}

extension DoubleModelQueryProperty
    on QueryBuilder<DoubleModel, QQueryProperty> {
  QueryBuilder<int?, QQueryOperations> idProperty() {
    return addPropertyIndex(0);
  }

  QueryBuilder<double?, QQueryOperations> fieldProperty() {
    return addPropertyIndex(1);
  }
}

class _GeneratedIsarInterface implements IsarInterface {
  @override
  String get schemaJson => _schema;

  @override
  List<String> get instanceNames => _isar.keys.toList();

  @override
  IsarCollection getCollection(String instanceName, String collectionName) {
    final instance = _isar[instanceName];
    if (instance == null) throw 'Isar instance $instanceName is not open';
    switch (collectionName) {
      case 'BoolModel':
        return _boolModelCollection[instanceName]!;
      case 'LongModel':
        return _longModelCollection[instanceName]!;
      case 'MultiTypeModel':
        return _multiTypeModelCollection[instanceName]!;
      case 'IntModel':
        return _intModelCollection[instanceName]!;
      case 'StringModel':
        return _stringModelCollection[instanceName]!;
      case 'FloatModel':
        return _floatModelCollection[instanceName]!;
      case 'DateTimeModel':
        return _dateTimeModelCollection[instanceName]!;
      case 'UserModel':
        return _userModelCollection[instanceName]!;
      case 'LinkModelA':
        return _linkModelACollection[instanceName]!;
      case 'LinkModelB':
        return _linkModelBCollection[instanceName]!;
      case 'ConverterModel':
        return _converterModelCollection[instanceName]!;
      case 'Message':
        return _messageCollection[instanceName]!;
      case 'StringModelCIS':
        return _stringModelCISCollection[instanceName]!;
      case 'DoubleModel':
        return _doubleModelCollection[instanceName]!;
      default:
        throw 'Unknown collection';
    }
  }

  @override
  Map<String, dynamic> objectToJson(dynamic object) {
    if (object is BoolModel) {
      return {
        'id': object.id,
        'field': object.field,
      };
    }
    if (object is LongModel) {
      return {
        'id': object.id,
        'field': object.field,
      };
    }
    if (object is MultiTypeModel) {
      return {
        'id': object.id,
        'boolValue': object.boolValue,
        'intValue': object.intValue,
        'floatValue': object.floatValue,
        'longValue': object.longValue,
        'doubleValue': object.doubleValue,
        'dateTimeValue': object.dateTimeValue,
        'stringValue': object.stringValue,
        'bytesValue': object.bytesValue,
        'boolList': object.boolList,
        'intList': object.intList,
        'floatList': object.floatList,
        'longList': object.longList,
        'doubleList': object.doubleList,
        'dateTimeListValue': object.dateTimeListValue,
        'stringList': object.stringList,
      };
    }
    if (object is IntModel) {
      return {
        'id': object.id,
        'field': object.field,
      };
    }
    if (object is StringModel) {
      return {
        'id': object.id,
        'hashField': object.hashField,
        'valueField': object.valueField,
        'wordsField': object.wordsField,
      };
    }
    if (object is FloatModel) {
      return {
        'id': object.id,
        'field': object.field,
      };
    }
    if (object is DateTimeModel) {
      return {
        'id': object.id,
        'date': object.date,
        'dateNullable': object.dateNullable,
        'list': object.list,
        'listNullable': object.listNullable,
        'listElementNullable': object.listElementNullable,
        'listNullableElementNullable': object.listNullableElementNullable,
      };
    }
    if (object is UserModel) {
      return {
        'id': object.id,
        'name': object.name,
        'age': object.age,
        'admin': object.admin,
      };
    }
    if (object is LinkModelA) {
      return {
        'id': object.id,
        'name': object.name,
      };
    }
    if (object is LinkModelB) {
      return {
        'id': object.id,
        'name': object.name,
      };
    }
    if (object is ConverterModel) {
      return {
        'id': object.id,
        'boolValue': object.boolValue,
        'intValue': object.intValue,
        'longValue': object.longValue,
        'floatValue': object.floatValue,
        'doubleValue': object.doubleValue,
        'dateValue': object.dateValue,
        'stringValue': object.stringValue,
      };
    }
    if (object is Message) {
      return {
        'id': object.id,
        'message': object.message,
      };
    }
    if (object is StringModelCIS) {
      return {
        'id': object.id,
        'hashField': object.hashField,
        'valueField': object.valueField,
        'wordsField': object.wordsField,
      };
    }
    if (object is DoubleModel) {
      return {
        'id': object.id,
        'field': object.field,
      };
    }
    throw 'Unknown object type';
  }
}
